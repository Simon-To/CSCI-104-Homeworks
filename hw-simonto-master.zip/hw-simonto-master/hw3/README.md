# Homework 3

coloring.cpp take a map file via commandline, then color it such that no adjacent countries
have the same color. Please use "make" command for compilation.

MinHeap.h is an implementation of min-heap, where the top is always the smallest element
in the entire data structure in terms of priority
