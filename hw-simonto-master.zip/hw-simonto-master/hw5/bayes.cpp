//
//  main.cpp
//  Naive Bayes’ Classifier
//
//  Created by Simon To on 14/4/21.
//

#include <algorithm>
#include <deque>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

using namespace std;

// Implemented with Laplacian Smoothing: Pr(x | C) = (1 + occ(x,C)) / (1 + occ(C))
double P_feature_given_class(double occ_class_with_feature, double occ_class);

// Implemented with Bayes' Theorem
double P_class_given_feature(
        double feature_given_class, double classific, double feature_given_not_class, double not_classific);

int main(int argc, const char* argv[]) {

    if (argc < 4) {
        cout << "Please specify a train, classify, and output file.";  //
        return 0;
    }

    // Input files: train.txt and classify.txt
    ifstream train_file(argv[1]);
    ifstream classify_file(argv[2]);
    stringstream ss;
    string train_line;  // changed to add std::

    // Output file: output,txt
    ofstream ofile(argv[3]);

    int object_num;  // The total number of objects provided, regardless of their classification
    getline(train_file, train_line);
    ss << train_line;
    ss >> object_num;  // The number that's provided on the first line of train.txt is fetched

    map<string, double> occ_of_class;    // key = class name, value = # of occ of that class
    map<string, double> occ_of_feature;  // key = feature name, value = # of occ of that feature
    map<string, map<string, double>>
            feature_to_class;  // key = feature, value = (map of <string, double>) given a feature, the number of object
                               // of each class to have that feature.
    for (int i = 0; i < object_num; i++) {
        getline(train_file, train_line);
        stringstream ss2(train_line);

        // Take care of the object (It's the first thing on each line)
        string object;
        ss2 >> object;  // Fetch object name

        map<string, double>::iterator class_loc = occ_of_class.find(object);  // Try to find the object.
        if (class_loc == occ_of_class.end()) {  // The class of this object has never been seen
            pair<string, double> new_class;
            new_class.first = object;        // Name of the class is the object
            new_class.second = 1;            // Occurance count start at 1
            occ_of_class.insert(new_class);  // Inserting as a new class
        } else {                             // The class of this object already exist
            class_loc->second += 1;          // Simply increment the number of occurances of that class by 1
        }

        set<string> attri_du_checker;  // Stores the attributes of this object

        string attribute;
        while (ss2 >> attribute) {  // As long as there's another attribute

            // Firstly, let's check if this is a duplicate attribute for the object that we're looking at right now.
            set<string>::iterator att_du_check = attri_du_checker.find(attribute);
            if (att_du_check
                == attri_du_checker.end()) {         // This attribute has never been seen for this particular object
                attri_du_checker.insert(attribute);  // Add this attribute to the checker map

                // Proceed to perform necessary operation on this attribute
                map<string, double>::iterator feature_loc = occ_of_feature.find(attribute);
                if (feature_loc == occ_of_feature.end()) {  // The feature of this object has never been seen
                    // Take care of occ_of_feature
                    pair<string, double> new_feature;
                    new_feature.first = attribute;       // Name of the feature is this attribute
                    new_feature.second = 1;              // Occurance count start at 1
                    occ_of_feature.insert(new_feature);  // Inserting as a new feature

                    // Take care of feature_to_class
                    map<string, double> class_per_feature;
                    pair<string, double> first_class;       // The first class in the newly created feature
                    first_class.first = object;             // Name of the class is the object
                    first_class.second = 1;                 // Occurance count start at 1
                    class_per_feature.insert(first_class);  // Inserting as a new class

                    pair<string, map<string, double>> new_feature_to_class;  // The new feature
                    new_feature_to_class.first = attribute;
                    new_feature_to_class.second = class_per_feature;
                    feature_to_class.insert(new_feature_to_class);
                } else {  // The feature of this object already exist
                    // Take care of occ_of_feature
                    feature_loc->second += 1;  // Simply increment the number of occurances of that feature by 1

                    // Take care of feature_to_class
                    map<string, map<string, double>>::iterator feature_class_loc
                            = feature_to_class.find(attribute);  // Get the location of the feature
                    map<string, double>::iterator class_of_f_loc
                            = (feature_class_loc->second)
                                      .find(object);  // Check if the current class exist in this feature
                    if (class_of_f_loc
                        == (feature_class_loc->second).end()) {     // The current class doesn't exist in this feature
                        pair<string, double> new_class_in_feature;  // The new class in the existing feature
                        new_class_in_feature.first = object;        // Name of the class is the object
                        new_class_in_feature.second = 1;            // Occurance count start at 1
                        (feature_class_loc->second)
                                .insert(new_class_in_feature);  // Insert into the feature_class_loc->second map
                    } else {                                    // The current class DO exist in this feature
                        class_of_f_loc->second += 1;  // Simply increment the number of occurances of that class by 1
                    }
                }
            }

            // else: This attribute has already been seen for this particular object, ignore this duplicate
        }
    }
    train_file.close();

    stringstream ss3;
    string classify_line;  // changed to add std::

    // Take care of classify_file
    int unclassified;  // The total number of objects provided, regardless of their classification
    getline(classify_file, classify_line);
    ss3 << classify_line;
    ss3 >> unclassified;  // The number that's provided on the first line of train.txt is fetched

    vector<vector<string>> classification;  // Stores all the data in classify.txt

    // Entering data from classify_file to our data structure
    for (int j = 0; j < unclassified; j++) {
        getline(classify_file, classify_line);
        stringstream ss4(classify_line);
        vector<string> to_add;  // Initialize a temporary string vector to store a line of data
        set<string> classify_du_checker;
        string requirement;  // Initialize a temporary string to store a single data in a line
        while (ss4 >> requirement) {
            set<string>::iterator cla_du_check = classify_du_checker.find(requirement);
            if (cla_du_check == classify_du_checker.end()) {  // This requirement of this object has never been seen
                classify_du_checker.insert(requirement);
                to_add.push_back(requirement);  // Add the word to the vector of classifications
            }
            // else: This requirement of this object has already been seen, ignore this duplicate
        }
        classification.push_back(to_add);  // Inserting this row of data.
    }
    classify_file.close();

    vector<string> output;  // Actual output of result: The item with the highest possibility

    for (int k = 0; k < unclassified; k++) {  // Calculating a specific unclassified item.
        map<string, double>::iterator class_it;
        deque<pair<string, double>> all_possibilities;  // To store all the classes' possibility for an described item

        for (class_it = occ_of_class.begin(); class_it != occ_of_class.end();
             ++class_it) {  // Looking at a specific class
            double feature_given_class = 1;
            double feature_given_not_class = 1;

            double occ_class = class_it->second;            // The number of objects that belong to that class
            double occ_not_class = object_num - occ_class;  // The number of objects that DON'T belong to that class

            double classific = (occ_class / object_num);          // Probability of that class
            double not_classific = (occ_not_class / object_num);  // Probability of NOT that class

            for (int l = 0; l < (int)(classification[k].size()); l++) {  // Looking at a specific given classification
                double occ_class_with_feature;
                double occ_not_class_with_feature;
                // map<string, map<string, double>> feature_to_class;
                map<string, map<string, double>>::iterator feature_it
                        = feature_to_class.find(classification[k][l]);  // Attempt to find that feature in data base
                if (feature_it == feature_to_class.end()) {             // Feature is NOT found
                    occ_class_with_feature = 0;
                    occ_not_class_with_feature = 0;
                    // The above two variables are all zero because the said feature DOES NOT exist in our data base.
                } else {  // Feature is FOUND
                    map<string, double>::iterator occ_feature = occ_of_feature.find(classification[k][l]);
                    map<string, double>::iterator feature_class_it = (feature_it->second).find(class_it->first);
                    if (feature_class_it
                        == (feature_it->second).end()) {  // No member of that class has the given feature
                        occ_class_with_feature = 0;       // The target class doesn't have that feature
                        occ_not_class_with_feature
                                = occ_feature->second;  // Since none of the objects under target class has the feature
                    } else {                            // Member of that class who has the given feature DO EXIST
                        occ_class_with_feature = feature_class_it->second;  // occ(x, C)
                        occ_not_class_with_feature
                                = (occ_feature->second) - (feature_class_it->second);  // occ(x, not C)
                    }
                }

                // Now we can calculate the Pr(x | C) for this particular class
                double this_feature_given_class = P_feature_given_class(occ_class_with_feature, occ_class);
                double this_feature_given_not_class = P_feature_given_class(occ_not_class_with_feature, occ_not_class);

                // Update the overall product
                feature_given_class *= this_feature_given_class;
                feature_given_not_class *= this_feature_given_not_class;
            }

            // Now we store the result in the priority queue: all_possibilities
            double current_possibility
                    = P_class_given_feature(feature_given_class, classific, feature_given_not_class, not_classific);
            string current_class = class_it->first;
            pair<string, double> new_insertion;
            new_insertion.first = current_class;
            new_insertion.second = current_possibility;

            // Begin insertion
            if (all_possibilities.empty() == true) {  // Special case: The whole priority queue is empty
                all_possibilities.push_front(new_insertion);
            } else {
                // The newly inserted probability is higher than the existing maximum, then push front. Otherwise, push
                // back.
                if (new_insertion.second >= ((all_possibilities.front()).second)) {
                    all_possibilities.push_front(new_insertion);
                } else {
                    all_possibilities.push_back(new_insertion);
                }
            }
        }

        output.push_back((all_possibilities.front()).first);
    }

    // Output to output.txt
    for (int s = 0; s < (int)(output.size()); s++) {
        if (s == ((int)(output.size()) - 1)) {  // Reached the very last element, avoid endl
            ofile << output[s];
        } else {
            ofile << output[s] << endl;
        }
    }

    return 0;
}

// Implemented with Laplacian Smoothing: Pr(x | C) = (1 + occ(x,C)) / (1 + occ(C))
double P_feature_given_class(double occ_class_with_feature, double occ_class) {
    double result = ((1 + occ_class_with_feature) / (1 + occ_class));
    return result;
}

// Implemented with Bayes' Theorem
double P_class_given_feature(
        double feature_given_class, double classific, double feature_given_not_class, double not_classific) {
    double result
            = ((feature_given_class * classific)
               / ((feature_given_class * classific) + (feature_given_not_class * not_classific)));
    return result;
}
