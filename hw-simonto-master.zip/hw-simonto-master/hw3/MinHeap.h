//
//  MinHeap.h
//  MinHeap
//
//  Created by Simon To on 12/3/21.
//

#ifndef MinHeap_h
#define MinHeap_h

#include <cmath>
#include <utility>
#include <vector>
#include <stdexcept>//change made after marking


template<class T>
class MinHeap {
public:
    MinHeap(int d);
    /* Constructor that builds a d-ary Min Heap
     This should work for any d >= 2,
     but doesn't have to do anything for smaller d.*/

    ~MinHeap();

    void add(T item, int priority);
    /* adds the item to the heap, with the given priority. */

    const T& peek() const;
    /* returns the element with smallest priority.
     Break ties however you wish.
     Throws an exception if the heap is empty. */

    void remove();
    /* removes the element with smallest priority.
     Break ties however you wish.
     Throws an exception if the heap is empty. */

    bool isEmpty();
    /* returns true iff there are no elements on the heap. */
    
// deleted merge marker

private:
    // whatever you need to naturally store things.
    std::vector<std::pair<T, int>> heap;  // storage of heap, start at index 0. <T item, int priority>
    int d_;                               // this is a d_-ary minheap

    // You may also add helper functions here.
    void trickleUp(int index);    // trickle up (recursive method): takes a index location in the heap and trickle its
                                  // content up in the heap
    void trickleDown(int index);  // trickle down (recursive method): takes a index location in the heap and trickle its
                                  // content up in the heap
};

/* Constructor that builds a d-ary Min Heap
 This should work for any d >= 2,
 but doesn't have to do anything for smaller d.*/
template<typename T>
MinHeap<T>::MinHeap(int d) {
    if (d >= 2) {
        d_ = d;  // this is a d-ary minheap
    }
}

template<typename T>
MinHeap<T>::~MinHeap() {
    // DON'T FORGET TO DELETE
    // DESTRUCTOR NOT IMPLEMENTED YET!!!
    heap.clear();
}

/* trickleUp and trickleDown are considered, by me, the
 most important functions, so I put them here before
 other public methods*/

template<typename T>
void MinHeap<T>::trickleUp(int index) {
    if (index != 0) {
        int parent = ((int)ceil((double)index / (double)d_)) - 1;

        if (heap[parent].second > heap[index].second) {  // base case: swap only if: 1. we're not at the top. AND 2. the
                                                         // parent node has a larger priority number
            // now swap
            std::pair<T, int> temp = heap[parent];
            heap[parent] = heap[index];
            heap[index] = temp;
            trickleUp(parent);
        }
    }
}

template<typename T>
void MinHeap<T>::trickleDown(int index) {

    int i = 1;                              // we start checking from the first child
    int smallest_child = (index * d_) + i;  // index of first child
    int this_child = (index * d_) + i + 1;  // index of second child

    if (smallest_child < (int)(heap.size())) {  // base case: heap[index] is not a leaf node

        // to trickle down, we gotta find the smallest child first
        while ((i < d_)
               && (this_child < (int)(heap.size()))) {  // check only if this item is 1. a child of heap[index].
                                                        // 2. this child and smallest child are within bound
            if (heap[this_child].second < heap[smallest_child].second) {  // we've found a smaller child?
                smallest_child = this_child;
            }
              // in the next iteration, we need to check the next child
            ++i;
            this_child = (index * d_) + i + 1;
        }

        // Now we need to determine whether we NEED to do any swap at all
        if (heap[index].second
            > heap[smallest_child].second) {  // we swap only when heap[index] is larger than heap[smallest_child]
            // and now, we swap with the smallest child
            std::pair<T, int> temp = heap[index];
            heap[index] = heap[smallest_child];
            heap[smallest_child] = temp;

            // finally, we recurse
            trickleDown(smallest_child);
        }
    }
}

/* returns the element with smallest priority.
 Break ties however you wish.
 Throws an exception if the heap is empty. */
template<typename T>
const T& MinHeap<T>::peek() const {
    // because trickleUp will only swap if the parent's priority is larger, a tie is
    // broken by the order of which the items are added to the heap.

    if (heap.empty() == true) {
        throw std::invalid_argument("Operation invalid due to the heap being empty!");
    }
    return heap[0].first;
}

/* adds the item to the heap, with the given priority. */
template<typename T>
void MinHeap<T>::add(T item, int priority) {
    // Trickle up
    std::pair<T, int> new_item;
    new_item.first = item;
    new_item.second = priority;
    heap.push_back(new_item);
    trickleUp((int)heap.size() - 1);
}

/* removes the element with smallest priority.
 Break ties however you wish.
 Throws an exception if the heap is empty. */
template<typename T>
void MinHeap<T>::remove() {
    // Swap
    // We don't really have to preserve the top's pair, because it's gonna be deleted anyway

    if (heap.empty() == true) {
        throw std::invalid_argument("Operation invalid due to the heap being empty!");
    }

    heap[0] = heap.back();
    heap.pop_back();

    // Trickle down
    trickleDown(0);
}

/* returns true iff there are no elements on the heap. */
template<typename T>
bool MinHeap<T>::isEmpty() {
    if (heap.empty() == true) {
        return true;
    } else {
        return false;
    }
}

// deleted merge marker
#endif /* MinHeap_h */
