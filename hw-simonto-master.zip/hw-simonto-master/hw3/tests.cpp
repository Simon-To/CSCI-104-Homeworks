#include "MinHeap.h"

#include <vector>
#include <algorithm>
#include <random>
#include <string>
#include <iostream>
#include <stdexcept>

// #include "curricula.hpp"

using namespace std;

int contents_ordered(int size, MinHeap<int>& heap)
{
    for (int i = 0; i < size; ++i)
    {
        if (heap.isEmpty())
        {
            return 1;
        }
        if (heap.peek() != i)
        {
            return 1;
        }
        heap.remove();
    }
    if (!heap.isEmpty())
    {
        return 1;
    }
    return 0;
}

int stress(int size, MinHeap<int>& heap)
{
    vector<int> benchmark(size);

    int i;
    vector<int>::iterator it;
    for (it = benchmark.begin(), i = 0; it != benchmark.end(); ++it, ++i)
    {
        *it = i;
    }

    unsigned int seed = 69420;
    shuffle(benchmark.begin(), benchmark.end(), default_random_engine(seed));

    for (auto it = benchmark.begin(); it != benchmark.end(); ++it)
    {
        heap.add(*it, *it);
    }

    return contents_ordered(size, heap);
}

TESTS_BEGIN

TEST(initialize)
{
    MinHeap<int> heap(2);
    return 0;
}

TEST(initialize_empty)
{
    MinHeap<int> heap(2);
    EXPECT_TRUE(heap.isEmpty());
	return 0;
}

TEST(peek_empty)
{
    MinHeap<int> heap(2);
    EXPECT_THROW(heap.peek());
}

TEST(remove_empty)
{
    MinHeap<int> heap(2);
    try
    {
        heap.remove();
    }
    catch(...)
    {
    }
    return 0;
}

TEST(add_empty)
{
	MinHeap<int> heap(2);
	heap.add(2, 1);
	EXPECT_FALSE(heap.isEmpty());
	return 0;
}

TEST(add_peek)
{
    MinHeap<int> heap(2);
	heap.add(10, 1);
	EXPECT_EQUAL(10, heap.peek());
	return 0;
}

TEST(add_remove_empty)
{
    MinHeap<int> heap(2);
	heap.add(10, 1);
	heap.remove();
	EXPECT_TRUE(heap.isEmpty());
	return 0;
}

TEST(add_remove)
{
    MinHeap<int> heap(2);
	heap.add(10, 3);
	heap.add(20, 10);
	EXPECT_EQUAL(10, heap.peek());
	heap.remove();
	EXPECT_EQUAL(20, heap.peek());
	return 0;
}

TEST(add_remove_ba)
{
    MinHeap<int> heap(2);
	heap.add(10, 50);
	heap.add(20, 49);
	EXPECT_EQUAL(20, heap.peek());
	heap.remove();
	EXPECT_EQUAL(10, heap.peek());
	return 0;
}

TEST(add_duplicate)
{
    MinHeap<int> heap(2);
	heap.add(20, 9);
	heap.add(10, 9);
	EXPECT_TRUE((heap.peek() == 10) || (heap.peek() == 20));
	return 0;
}

TEST(add_remove_many)
{
    MinHeap<int> heap(2);
	heap.add(10, 0);
	heap.add(20, 5);
	heap.add(30, 10);
	EXPECT_EQUAL(10, heap.peek());
	heap.remove();
	EXPECT_EQUAL(20, heap.peek());
	heap.remove();
	EXPECT_EQUAL(30, heap.peek());
	return 0;
}

TEST(add_remove_many_acb)
{
    MinHeap<int> heap(2);
	heap.add(10, 0);
	heap.add(30, 10);
	heap.add(20, 5);
	EXPECT_EQUAL(10, heap.peek());
	heap.remove();
	EXPECT_EQUAL(20, heap.peek());
	heap.remove();
	EXPECT_EQUAL(30, heap.peek());
	return 0;
}

TEST(add_remove_many_bac)
{
    MinHeap<int> heap(2);
	heap.add(20, 5);
	heap.add(10, 0);
	heap.add(30, 10);
	EXPECT_EQUAL(10, heap.peek());
	heap.remove();
	EXPECT_EQUAL(20, heap.peek());
	heap.remove();
	EXPECT_EQUAL(30, heap.peek());
	return 0;
}

TEST(add_remove_many_bca)
{
    MinHeap<int> heap(2);
	heap.add(20, 5);
	heap.add(30, 10);
	heap.add(10, 0);
	EXPECT_EQUAL(10, heap.peek());
	heap.remove();
	EXPECT_EQUAL(20, heap.peek());
	heap.remove();
	EXPECT_EQUAL(30, heap.peek());
	return 0;
}

TEST(add_remove_many_cab)
{
    MinHeap<int> heap(2);
	heap.add(30, 10);
	heap.add(10, 0);
	heap.add(20, 5);
	EXPECT_EQUAL(10, heap.peek());
	heap.remove();
	EXPECT_EQUAL(20, heap.peek());
	heap.remove();
	EXPECT_EQUAL(30, heap.peek());
	return 0;
}

TEST(add_remove_many_cba)
{
	MinHeap<int> heap(2);
	heap.add(30, 10);
	heap.add(20, 5);
	heap.add(10, 0);
	EXPECT_EQUAL(10, heap.peek());
	heap.remove();
	EXPECT_EQUAL(20, heap.peek());
	heap.remove();
	EXPECT_EQUAL(30, heap.peek());
	return 0;
}

TEST(add_remove_many_string)
{
    MinHeap<string> stringHeap(2);
	stringHeap.add("blah", 25);
	stringHeap.add("bluh", 30);
	stringHeap.add("bloh", 35);
	EXPECT_EQUAL("blah", stringHeap.peek());
	stringHeap.remove();
	EXPECT_EQUAL("bluh", stringHeap.peek());
	stringHeap.remove();
	EXPECT_EQUAL("bloh", stringHeap.peek());
	return 0;
}

TEST(ternary_add_remove_many)
{
    MinHeap<int> heap(3);
	heap.add(10, 0);
	heap.add(20, 5);
	heap.add(30, 10);
	EXPECT_EQUAL(10, heap.peek());
	heap.remove();
	EXPECT_EQUAL(20, heap.peek());
	heap.remove();
	EXPECT_EQUAL(30, heap.peek());
	return 0;
}

TEST(quaternary_add_remove_many)
{
    MinHeap<int> heap(4);
	heap.add(10, 0);
	heap.add(20, 5);
	heap.add(30, 10);
	EXPECT_EQUAL(10, heap.peek());
	heap.remove();
	EXPECT_EQUAL(20, heap.peek());
	heap.remove();
	EXPECT_EQUAL(30, heap.peek());
	return 0;
}

TEST(stress)
{
    MinHeap<int> heap(2);
    return stress(5000, heap);
}

TEST(quaternary_stress)
{
    MinHeap<int> heap(4);
    return stress(5000, heap);
}

TEST(duodenary_stress)
{
    MinHeap<int> heap(12);
    return stress(5000, heap);
}

TEST(stress_heavy)
{
    MinHeap<int> heap(2);
    return stress(10000, heap);
}

TESTS_END
