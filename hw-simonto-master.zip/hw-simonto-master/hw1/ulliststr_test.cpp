/* Write your test code for the ULListStr in this file */

#include "ulliststr.h"  //
#include <cstddef>
#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {
    // test cases should include the following scenarios:
    /*
     1. When the list is empty
     2. when the a new item has to be added
     3. when an old item needs to be deleted
     4. when an entire list needs to be deleted
     5. when trying to access an element that is out-of-bound
     6. faithfully track the start and end of the whole list

     push_back:
     normal
     1
     2

     push_front:
     normal
     1
     2

     pop_back:
     normal
     3
     4

     pop_front:
     normal
     3
     4

     back:
     normal
     6

     front
     normal
     6

     getValAtLoc:
     normal
     5

     */

    ULListStr dat;
    dat.push_back("0");           // Scenario 1, 2
    dat.push_front("1");          // Scenario 2
    dat.push_back("4");           // Normal Scenario
    cout << dat.front() << endl;  // Scenario 6: should output 1
    cout << dat.back() << endl;   // Scenario 6: should output 4
    cout << dat.get(0) << " " << dat.get(1) << " " << dat.get(2) << endl;
    // prints: 1 0 4
    // dat.get(3); // Scenario 5: should output "Bad location" (THIS LINE IS PART OF THE TEST! QUOTED FOR CONTINUATION
    // OF THE REST OF THE TEST)
    dat.pop_front();              // Scenario 3: delete 1
    dat.pop_back();               // delete 4
    cout << dat.front() << endl;  // should be 0
    cout << dat.size() << endl;   // should be 1
    dat.pop_front();              // Scenario 4: the list should be deleted after this, check valgrind for mem leak

    return 0;
}
