Homework 1:

Part 1:
split.cpp is a program dedicated to split a singly-linked list into two singly-linked list
where one of the linked-list contains all the even numbers and another contains all the
odd numbers in the original singly-linked list.

Part 2:
ulliststr.cpp is a program that can create a doubly-linked list where each node is an
array of strings. 
ulliststr_test.cpp provides a test that checks whether all the edge cases are behaving
correctly.