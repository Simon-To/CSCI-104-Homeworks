//
//  clothing.cpp
//
//
//  Created by Simon To on 16/2/21.
//

#include "clothing.h"

#include "product.h"
#include "util.h"
#include <iostream>
#include <sstream>
#include <string.h>

using namespace std;

Clothing::Clothing(
        const std::string category,
        const std::string name,
        double price,
        int qty,
        const std::string size,
        const std::string brand)
        : Product(category, name, price, qty) {
    size_ = size;
    brand_ = brand;
}

Clothing::~Clothing() {}

/**
 * Returns the appropriate keywords that this product should be associated with
 */
std::set<std::string> Clothing::keywords() const {
    std::set<std::string> key_words;

    std::set<std::string> parsed_name = parseStringToWords(name_);
    key_words.insert(parsed_name.begin(), parsed_name.end());

    std::set<std::string> parsed_brand = parseStringToWords(brand_);
    key_words.insert(parsed_brand.begin(), parsed_brand.end());

    return key_words;
}

/**
 * Returns a string to display the product info for hits of the search
 */
std::string Clothing::displayString() const {
    std::string info_display;

    info_display.append(name_);
    info_display.append("\n");
    info_display.append("Size: ");
    info_display.append(size_);
    info_display.append(" Brand: ");
    info_display.append(brand_);
    info_display.append("\n");
    std::ostringstream conv_price;
    conv_price << price_;
    std::string str_price = conv_price.str();
    info_display.append(str_price);
    info_display.append(" ");
    info_display.append(std::to_string(qty_));
    info_display.append(" left.");
    info_display.append("\n");

    return info_display;
}

/**
 * Outputs the product info in the database format
 */
void Clothing::dump(std::ostream& os) const {
    os << "clothing\n";
    os << name_;
    os << "\n";
    os << price_;
    os << "\n";
    os << qty_;
    os << "\n";
    os << size_;
    os << "\n";
    os << brand_;
    os << "\n";
}

// Below are the member variable that we have:
