//
//  Hashtable.h
//  Hashtable
//
//  Created by Simon To on 26/4/21.
//

#ifndef Hashtable_h
#define Hashtable_h

#include <cmath>
#include <iostream>
#include <utility>

class Hashtable {
public:
    Hashtable(bool debug = false, unsigned int probing = 0);  // Constructor
    ~Hashtable();                                             // Destructor
    void add(std::string k);                                  // Increment value by 1
    int count(std::string k);                // Return the value associate with key (0 if k is not in the Hashtable)
    void reportAll(std::ostream& os) const;  // Output all pairs

private:
    // Member functions (methods):
    void resize();                   // Approximately double the size of the hashtable
    int hash(std::string k) const;   // Takes a string and outputs a pseudo-random index
    int hash2(std::string k) const;  // Second hash function for determining the step size in double-hashing
    std::pair<std::string, int>* find(std::string k);  // Helper function used in count() and add()
    int next_empty(
            std::string k, std::pair<std::string, int>** target_table);  // Helper function used in resize() and add()
    void five_random(int m);  // generate 5 new r values that are random numbers between 0 and m-1 (inclusive)
    void w_calculator(std::string k, int (&w)[5]) const;  // return w1 w2 w3 w4 w5 in an int array

    // Member variables:
    std::pair<std::string, int>** table;  // Storage of all pairs
    int table_size;                       // Total size of the table, m
    int current_size;                     // Current number of pairs store in the table, n
    bool debug_mode;  // 1 = Debug mode on, use: r1=983132572, r2=62337998, r3=552714139, r4=984953261, r5=261934300
    unsigned int probing_mode;
    int r[5];
    int available_sizes[28] = {  // All available sizes for this hashtable
            11,       23,       47,       97,        197,       397,       797,       1597,      3203,    6421,
            12853,    25717,    51437,    102877,    205759,    411527,    823117,    1646237,   3292489, 6584983,
            13169977, 26339969, 52679969, 105359969, 210719881, 421439783, 842879579, 1685759167};
    int size_tracker;  // Tracks the table size's position in available_sizes array

    int available_p[28] = {  // All available p values for this hashtable's double hashing
            7,        19,       43,       89,        193,       389,       787,       1583,      3191,    6397,
            12841,    25703,    51431,    102871,    205721,    411503,    823051,    1646221,   3292463, 6584957,
            13169963, 26339921, 52679927, 105359939, 210719881, 421439749, 842879563, 1685759113};
};

#endif /* Hashtable_h */
