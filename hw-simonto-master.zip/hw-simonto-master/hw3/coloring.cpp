//
//  main.cpp
//  coloring
//
//  Created by Simon To on 8/3/21.
//

#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>

using namespace std;

bool isValid(
        map<char, int>* countries_colors,
        map<char, set<char>>* countries_neighbors,
        std::map<char, std::set<char>>::iterator it_countries_neighbors);

bool solveHelper(
        map<char, int>* countries_colors,
        map<char, set<char>>* countries_neighbors,
        std::map<char, std::set<char>>::iterator it_countries_neighbors);

int main(int argc, const char* argv[]) {

    map<char, int> coloring;
    map<char, set<char>> countries_neighbors;
    map<char, int>* pointer_countries_colors = &coloring;
    map<char, set<char>>* pointer_countries_neighbors = &countries_neighbors;
    int countries_num;
    int rows_num;
    int cols_num;

    if (argc != 2) {
        std::cout << "Map file either not provided or incorrectly provided!" << std::endl;
    }

    std::string filename = argv[1];

    ifstream input;
    input.open(filename);
    input >> countries_num >> rows_num >> cols_num;

    char map[rows_num][cols_num];

    for (int i = 0; i < rows_num; ++i) {
        for (int j = 0; j < cols_num; ++j) {
            input >> map[i][j];
        }
    }

    set<char> temp;  // empty set just for insertion syntax
    for (int i = 0; i < rows_num; ++i) {
        for (int j = 0; j < cols_num; ++j) {
            if ((j > 0) && (i > 0)) {  // We're not on first row or first column (common case)
                if (countries_neighbors.find(map[i][j])
                    == countries_neighbors.end()) {  // This is a brand new country that we found
                    countries_neighbors.insert(pair<char, set<char>>(map[i][j], temp));  // Create a new country
                    coloring.insert(pair<char, int>(map[i][j], -1));  // Create the country's color, default -1
                    if (map[i][j] != map[i][j - 1]) {                 // This new country has a neighbor on the left
                        (countries_neighbors.find(map[i][j]))->second.insert(map[i][j - 1]);  // add to new country
                        (countries_neighbors.find(map[i][j - 1]))->second.insert(map[i][j]);  // add to previous country
                    }
                    if (map[i][j] != map[i - 1][j]) {  // This new country has a neighbor on the top
                        (countries_neighbors.find(map[i][j]))->second.insert(map[i - 1][j]);  // add to new country
                        (countries_neighbors.find(map[i - 1][j]))->second.insert(map[i][j]);  // add to previous country
                    }
                }
                // Every case below is for an existing country. We need to check both left and top
                else {
                    if ((map[i][j] != map[i][j - 1])
                        && ((countries_neighbors.find(map[i][j]))->second.find(map[i][j - 1]))
                                   == (countries_neighbors.find(map[i][j]))
                                              ->second.end()) {  // This country has a new neighbor on the left
                        (countries_neighbors.find(map[i][j]))->second.insert(map[i][j - 1]);  // add to new country
                        (countries_neighbors.find(map[i][j - 1]))->second.insert(map[i][j]);  // add to previous country
                    }
                    if (map[i][j] != map[i - 1][j]
                        && ((countries_neighbors.find(map[i][j]))->second.find(map[i - 1][j]))
                                   == (countries_neighbors.find(map[i][j]))
                                              ->second.end()) {  // This country has a new neighbor on the top
                        (countries_neighbors.find(map[i][j]))->second.insert(map[i - 1][j]);  // add to new country
                        (countries_neighbors.find(map[i - 1][j]))->second.insert(map[i][j]);  // add to previous country
                    }
                }
            } else if ((j == 0) && (i > 0)) {  // We're not on first row but on first column (SHOULD NOT check left)
                if (countries_neighbors.find(map[i][j])
                    == countries_neighbors.end()) {  // This is a brand new country that we found
                    countries_neighbors.insert(pair<char, set<char>>(map[i][j], temp));  // Create a new country
                    coloring.insert(pair<char, int>(map[i][j], -1));  // Create the country's color, default -1
                    if (map[i][j] != map[i - 1][j]) {                 // This new country has a neighbor on the top
                        (countries_neighbors.find(map[i][j]))->second.insert(map[i - 1][j]);  // add to new country
                        (countries_neighbors.find(map[i - 1][j]))->second.insert(map[i][j]);  // add to previous country
                    }
                } else {  // Only checking top in the code below
                    if (map[i][j] != map[i - 1][j]
                        && ((countries_neighbors.find(map[i][j]))->second.find(map[i - 1][j]))
                                   == (countries_neighbors.find(map[i][j]))
                                              ->second.end()) {  // This country has a new neighbor on the top
                        (countries_neighbors.find(map[i][j]))->second.insert(map[i - 1][j]);  // add to new country
                        (countries_neighbors.find(map[i - 1][j]))->second.insert(map[i][j]);  // add to previous country
                    }
                }
            } else if ((j > 0) && (i == 0)) {  // We're on first row but not on first column (SHOULD NOT check top)
                if (countries_neighbors.find(map[i][j])
                    == countries_neighbors.end()) {  // This is a brand new country that we found
                    countries_neighbors.insert(pair<char, set<char>>(map[i][j], temp));  // Create a new country
                    coloring.insert(pair<char, int>(map[i][j], -1));  // Create the country's color, default -1
                    if (map[i][j] != map[i][j - 1]) {                 // This new country has a neighbor on the left
                        (countries_neighbors.find(map[i][j]))->second.insert(map[i][j - 1]);  // add to new country
                        (countries_neighbors.find(map[i][j - 1]))->second.insert(map[i][j]);  // add to previous country
                    }
                } else {  // Only checking left in the code below
                    if ((map[i][j] != map[i][j - 1])
                        && ((countries_neighbors.find(map[i][j]))->second.find(map[i][j - 1]))
                                   == (countries_neighbors.find(map[i][j]))
                                              ->second.end()) {  // This country has a new neighbor on the left
                        (countries_neighbors.find(map[i][j]))->second.insert(map[i][j - 1]);  // add to new country
                        (countries_neighbors.find(map[i][j - 1]))->second.insert(map[i][j]);  // add to previous country
                    }
                }
            } else {  // We're on first row and first column
                      // (This is the very first element, no checking is required)
                countries_neighbors.insert(pair<char, set<char>>(map[i][j], temp));  // Create a new country
                coloring.insert(pair<char, int>(map[i][j], -1));  // Create the country's color, default -1
            }
        }
    }

    std::map<char, std::set<char>>::iterator first_country = countries_neighbors.begin();
    std::map<char, int>::iterator first_color_country;

    solveHelper(pointer_countries_colors, pointer_countries_neighbors, first_country);

    for (first_color_country = coloring.begin(); first_color_country != coloring.end(); ++first_color_country) {
        cout << first_color_country->first << " " << first_color_country->second << endl;
    }

    return 0;
}

bool isValid(
        map<char, int>* countries_colors,
        map<char, set<char>>* countries_neighbors,
        std::map<char, std::set<char>>::iterator it_countries_neighbors) {

    int domestic_color = (countries_colors->find(it_countries_neighbors->first))->second;

    std::set<char>::iterator set_itr;
    for (set_itr = (it_countries_neighbors->second).begin(); set_itr != (it_countries_neighbors->second).end();
         ++set_itr) {
        int current_color = (countries_colors->find(*set_itr))->second;
        if (current_color == domestic_color) {  // && (domestic_color != -1)
            return false;
        }
    }
    return true;
}

bool solveHelper(
        map<char, int>* countries_colors,
        map<char, set<char>>* countries_neighbors,
        std::map<char, std::set<char>>::iterator it_countries_neighbors) {

    if (it_countries_neighbors == countries_neighbors->end()) {
        return true;
    }

    int original_color = (countries_colors->find(it_countries_neighbors->first))->second;
    std::map<char, std::set<char>>::iterator original_itr = it_countries_neighbors;

    for (int i = 1; i < 5; ++i) {
        (countries_colors->find(it_countries_neighbors->first))->second = i;
        if (isValid(countries_colors, countries_neighbors, it_countries_neighbors) == true) {

            if (solveHelper(countries_colors, countries_neighbors, ++it_countries_neighbors) == true) {
                return true;
            } else {
                it_countries_neighbors = original_itr;
            }
        }
    }
    (countries_colors->find(it_countries_neighbors->first))->second = original_color;

    return false;
}
