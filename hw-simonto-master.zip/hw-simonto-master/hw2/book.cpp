//
//  book.cpp
//
//
//  Created by Simon To on 16/2/21.
//

#include "book.h"

#include "product.h"
#include "util.h"
#include <iostream>
#include <sstream>
#include <string.h>

using namespace std;

Book::Book(
        const std::string category,
        const std::string name,
        double price,
        int qty,
        const std::string ISBN,
        const std::string author)
        : Product(category, name, price, qty) {
    ISBN_ = ISBN;
    author_ = author;
}

Book::~Book() {}

/**
 * Returns the appropriate keywords that this product should be associated with
 */
std::set<std::string> Book::keywords() const {
    std::set<std::string> key_words;

    std::set<std::string> parsed_name = parseStringToWords(name_);
    key_words.insert(parsed_name.begin(), parsed_name.end());

    key_words.insert(ISBN_);

    std::set<std::string> parsed_author = parseStringToWords(author_);
    key_words.insert(parsed_author.begin(), parsed_author.end());

    return key_words;
}

/**
 * Returns a string to display the product info for hits of the search
 */
std::string Book::displayString() const {
    std::string info_display;

    info_display.append(name_);
    info_display.append("\n");
    info_display.append("Author: ");
    info_display.append(author_);
    info_display.append(" ISBN: ");
    info_display.append(ISBN_);
    info_display.append("\n");
    std::ostringstream conv_price;
    conv_price << price_;
    std::string str_price = conv_price.str();
    info_display.append(str_price);
    info_display.append(" ");
    info_display.append(std::to_string(qty_));
    info_display.append(" left.");
    info_display.append("\n");

    return info_display;
}

/**
 * Outputs the product info in the database format
 */
void Book::dump(std::ostream& os) const {
    os << "book\n";
    os << name_;
    os << "\n";
    os << price_;
    os << "\n";
    os << qty_;
    os << "\n";
    os << ISBN_;
    os << "\n";
    os << author_;
    os << "\n";
}

// Below are the member variable that we have:
