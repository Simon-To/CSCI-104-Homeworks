#ifndef BST_H
#define BST_H

#include <cstdlib>
#include <exception>
#include <iostream>
#include <utility>

/**
 * A templated class for a Node in a search tree.
 * The getters for parent/left/right are virtual so
 * that they can be overridden for future kinds of
 * search trees, such as Red Black trees, Splay trees,
 * and AVL trees.
 */
template<typename Key, typename Value>
class Node {
public:
    Node(const Key& key, const Value& value, Node<Key, Value>* parent);
    virtual ~Node();

    const std::pair<const Key, Value>& getItem() const;
    std::pair<const Key, Value>& getItem();
    const Key& getKey() const;
    const Value& getValue() const;
    Value& getValue();

    virtual Node<Key, Value>* getParent() const;
    virtual Node<Key, Value>* getLeft() const;
    virtual Node<Key, Value>* getRight() const;

    void setParent(Node<Key, Value>* parent);
    void setLeft(Node<Key, Value>* left);
    void setRight(Node<Key, Value>* right);
    void setValue(const Value& value);

protected:
    std::pair<const Key, Value> item_;
    Node<Key, Value>* parent_;
    Node<Key, Value>* left_;
    Node<Key, Value>* right_;
};

/*
  -----------------------------------------
  Begin implementations for the Node class.
  -----------------------------------------
*/

/**
 * Explicit constructor for a node.
 */
template<typename Key, typename Value>
Node<Key, Value>::Node(const Key& key, const Value& value, Node<Key, Value>* parent)
        : item_(key, value), parent_(parent), left_(NULL), right_(NULL) {}

/**
 * Destructor, which does not need to do anything since the pointers inside of a node
 * are only used as references to existing nodes. The nodes pointed to by parent/left/right
 * are freed within the deleteAll() helper method in the BinarySearchTree.
 */
template<typename Key, typename Value>
Node<Key, Value>::~Node() {}

/**
 * A const getter for the item.
 */
template<typename Key, typename Value>
const std::pair<const Key, Value>& Node<Key, Value>::getItem() const {
    return item_;
}

/**
 * A non-const getter for the item.
 */
template<typename Key, typename Value>
std::pair<const Key, Value>& Node<Key, Value>::getItem() {
    return item_;
}

/**
 * A const getter for the key.
 */
template<typename Key, typename Value>
const Key& Node<Key, Value>::getKey() const {
    return item_.first;
}

/**
 * A const getter for the value.
 */
template<typename Key, typename Value>
const Value& Node<Key, Value>::getValue() const {
    return item_.second;
}

/**
 * A non-const getter for the value.
 */
template<typename Key, typename Value>
Value& Node<Key, Value>::getValue() {
    return item_.second;
}

/**
 * An implementation of the virtual function for retreiving the parent.
 */
template<typename Key, typename Value>
Node<Key, Value>* Node<Key, Value>::getParent() const {
    return parent_;
}

/**
 * An implementation of the virtual function for retreiving the left child.
 */
template<typename Key, typename Value>
Node<Key, Value>* Node<Key, Value>::getLeft() const {
    return left_;
}

/**
 * An implementation of the virtual function for retreiving the right child.
 */
template<typename Key, typename Value>
Node<Key, Value>* Node<Key, Value>::getRight() const {
    return right_;
}

/**
 * A setter for setting the parent of a node.
 */
template<typename Key, typename Value>
void Node<Key, Value>::setParent(Node<Key, Value>* parent) {
    parent_ = parent;
}

/**
 * A setter for setting the left child of a node.
 */
template<typename Key, typename Value>
void Node<Key, Value>::setLeft(Node<Key, Value>* left) {
    left_ = left;
}

/**
 * A setter for setting the right child of a node.
 */
template<typename Key, typename Value>
void Node<Key, Value>::setRight(Node<Key, Value>* right) {
    right_ = right;
}

/**
 * A setter for the value of a node.
 */
template<typename Key, typename Value>
void Node<Key, Value>::setValue(const Value& value) {
    item_.second = value;
}

/*
  ---------------------------------------
  End implementations for the Node class.
  ---------------------------------------
*/

/**
 * A templated unbalanced binary search tree.
 */
template<typename Key, typename Value>
class BinarySearchTree {
public:
    BinarySearchTree();                                                    // TODO
    virtual ~BinarySearchTree();                                           // TODO
    virtual void insert(const std::pair<const Key, Value>& keyValuePair);  // TODO
    virtual void remove(const Key& key);                                   // TODO
    void clear();                                                          // TODO
    bool isBalanced() const;                                               // TODO
    void print() const;
    bool empty() const;

public:
    /**
     * An internal iterator class for traversing the contents of the BST.
     */
    class iterator  // TODO
    {
    public:
        iterator();

        std::pair<const Key, Value>& operator*() const;
        std::pair<const Key, Value>* operator->() const;

        bool operator==(const iterator& rhs) const;
        bool operator!=(const iterator& rhs) const;

        iterator& operator++();

    protected:
        friend class BinarySearchTree<Key, Value>;
        iterator(Node<Key, Value>* ptr);
        Node<Key, Value>* current_;
    };

public:
    iterator begin() const;
    iterator end() const;
    iterator find(const Key& key) const;

protected:
    // Mandatory helper functions
    Node<Key, Value>* internalFind(const Key& k) const;               // TODO
    Node<Key, Value>* getSmallestNode() const;                        // TODO
    static Node<Key, Value>* predecessor(Node<Key, Value>* current);  // TODO
    // Note:  static means these functions don't have a "this" pointer
    //        and instead just use the input argument.

    // Provided helper functions
    virtual void printRoot(Node<Key, Value>* r) const;
    virtual void nodeSwap(Node<Key, Value>* n1, Node<Key, Value>* n2);

    // Add helper functions here
    int height(Node<Key, Value>*
                       root);  // recursive helper function that return the height of a given node, NOT-IN-USE yet.
    int
    balance(Node<Key, Value>* root,
            bool& children_balanced) const;  // An upgraded version of the above function with the ability to check if a
                                             // node's two children are balanced
    void deletion(Node<Key, Value>* root);   // recursively traverse the tree and delete each node.
    void adoption(
            Node<Key, Value>* parent,
            Node<Key, Value>* new_child,
            Node<Key, Value>* old_child);  // Special function for changing parent to aid nodeSwap

protected:
    Node<Key, Value>* root_;
    // You should not need other data members
};

/*
--------------------------------------------------------------
Begin implementations for the BinarySearchTree::iterator class.
---------------------------------------------------------------
*/

/**
 * Explicit constructor that initializes an iterator with a given node pointer.
 */
template<class Key, class Value>
BinarySearchTree<Key, Value>::iterator::iterator(Node<Key, Value>* ptr) {
    // Implemented by Simon
    // should initialize current_ to pointer to a specific Node<Key, Value>*
    current_ = ptr;
}

/**
 * A default constructor that initializes the iterator to NULL.
 */
template<class Key, class Value>
BinarySearchTree<Key, Value>::iterator::iterator()  // there used to be a ":" HERE
{
    // Implemented by Simon
    current_ = nullptr;
}

/**
 * Provides access to the item.
 */
template<class Key, class Value>
std::pair<const Key, Value>& BinarySearchTree<Key, Value>::iterator::operator*() const {
    return current_->getItem();
}

/**
 * Provides access to the address of the item.
 */
template<class Key, class Value>
std::pair<const Key, Value>* BinarySearchTree<Key, Value>::iterator::operator->() const {
    return &(current_->getItem());
}

/**
 * Checks if 'this' iterator's internals have the same value
 * as 'rhs'
 */
template<class Key, class Value>
bool BinarySearchTree<Key, Value>::iterator::operator==(const BinarySearchTree<Key, Value>::iterator& rhs) const {
    // Implemented by Simon
    bool same;
    if (this->current_ == rhs.current_) {
        same = true;
    } else {
        same = false;
    }
    return same;
}

/**
 * Checks if 'this' iterator's internals have a different value
 * as 'rhs'
 */
template<class Key, class Value>
bool BinarySearchTree<Key, Value>::iterator::operator!=(const BinarySearchTree<Key, Value>::iterator& rhs) const {
    // Implemented by Simon
    bool different;
    if (this->current_ != rhs.current_) {
        different = true;
    } else {
        different = false;
    }
    return different;
}

/**
 * Advances the iterator's location using an in-order sequencing
 */
template<class Key, class Value>
typename BinarySearchTree<Key, Value>::iterator& BinarySearchTree<Key, Value>::iterator::operator++() {
    // Implemented by Simon
    // make the current iterator point to its in-order successor in the BST
    /*
     If right child exists, successor is the left most node of the right subtree
     Else walk up the ancestor chain until you traverse the first left child pointer (find the first node who is a left
     child of his parent…that parent is the successor) If you get to the root w/o finding a node who is a left child,
     there is no successor
     */
    Node<Key, Value>* successor = nullptr;  // initializing the successor pointer
    Node<Key, Value>* right_child = ((this->current_)->getRight());
    Node<Key, Value>* next = nullptr;  // used to trace down the tree

    Node<Key, Value>* now = nullptr;   // used to trace up the tree
    Node<Key, Value>* prev = nullptr;  // used to trace up the tree
    if (right_child != nullptr) {      // If right child exist:

        if (right_child->getLeft() == nullptr) {  // If right child's left child DOESN'T exists:

            successor = right_child;  // Successor is the right child ITSELF.
            this->current_ = successor;
            return *this;
        } else {  // If right child's left child exists:
            next = right_child->getLeft();
            while (next != nullptr) {  // Successor is the left-most child of the right child
                successor = next;
                next = next->getLeft();  // updating next pointer
            }
            this->current_ = successor;
            return *this;
        }
    } else {  // If right child DOESN'T exist:
        now = this->current_;
        prev = (this->current_)->getParent();
        while (prev != nullptr) {  // Trace up the ancestor chain
            if (now == prev->getLeft()) {
                successor = prev;
                break;
            }
            now = prev;
            prev = now->getParent();
        }
        if (successor == nullptr) {  // // If the root is reached and still no left child pointer
            // this means there IS NO SUCCESSOR for this child
            this->current_ = nullptr;
            return *this;
        } else {  // successor is found successfully (pun intended)
            this->current_ = successor;
            return *this;
        }
    }
}

/*
-------------------------------------------------------------
End implementations for the BinarySearchTree::iterator class.
-------------------------------------------------------------
*/

/*
-----------------------------------------------------
Begin implementations for the BinarySearchTree class.
-----------------------------------------------------
*/

/**
 * Default constructor for a BinarySearchTree, which sets the root to NULL.
 */
template<class Key, class Value>
BinarySearchTree<Key, Value>::BinarySearchTree()  // there used to be a ":" HERE
{
    // Implemented by Simon
    this->root_ = nullptr;
}

template<typename Key, typename Value>
BinarySearchTree<Key, Value>::~BinarySearchTree() {
    // Implemented by Simon
    if (this->empty() != true) {

        this->clear();
    }
}

/**
 * Returns true if tree is empty
 */
template<class Key, class Value>
bool BinarySearchTree<Key, Value>::empty() const {
    return root_ == NULL;
}

template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::print() const {
    printRoot(root_);
    std::cout << "\n";
}

/**
 * Returns an iterator to the "smallest" item in the tree
 */
template<class Key, class Value>
typename BinarySearchTree<Key, Value>::iterator BinarySearchTree<Key, Value>::begin() const {
    BinarySearchTree<Key, Value>::iterator begin(getSmallestNode());
    return begin;
}

/**
 * Returns an iterator whose value means INVALID
 */
template<class Key, class Value>
typename BinarySearchTree<Key, Value>::iterator BinarySearchTree<Key, Value>::end() const {
    BinarySearchTree<Key, Value>::iterator end(NULL);
    return end;
}

/**
 * Returns an iterator to the item with the given key, k
 * or the end iterator if k does not exist in the tree
 */
template<class Key, class Value>
typename BinarySearchTree<Key, Value>::iterator BinarySearchTree<Key, Value>::find(const Key& k) const {
    Node<Key, Value>* curr = internalFind(k);
    BinarySearchTree<Key, Value>::iterator it(curr);
    return it;
}

/**
 * An insert method to insert into a Binary Search Tree.
 * The tree will not remain balanced when inserting.
 */
template<class Key, class Value>
void BinarySearchTree<Key, Value>::insert(const std::pair<const Key, Value>& keyValuePair) {
    // Implemented by Simon
    // NO NEED TO MAINTAIN BALANCE
    // 1. We need to see if this key already exists in BST
    Node<Key, Value>* search_result = internalFind(keyValuePair.first);
    if (search_result != nullptr) {                    // this key exists prior to this insertion
        search_result->setValue(keyValuePair.second);  // We just have to simply update the value of that pair
    } else {  // Unfortunately this key doesn't exist in the tree, so now we know we HAVE TO insert
        // 2. Find the appropriate location for insertion:
        Node<Key, Value>* locator = this->root_;  // We need to start from the root
        Node<Key, Value>* next = this->root_;     // We also need to keep track of the next pointer to search
        bool set_left = true;      // Assume our new node will be a left child, will change according to actual scenario
        while (next != nullptr) {  // the next pointer is not null
            locator = next;        // We're now examining a new location
            if (keyValuePair.first > locator->getKey()) {  // If our key is greater than this key
                next = locator->getRight();                // We should traverse the RIGHT child in the next iteration
                set_left = false;
            } else if (keyValuePair.first < locator->getKey()) {  // If our key is less than this key
                next = locator->getLeft();  // We should traverse the LEFT child in the next iteration
                set_left = true;
            }
        }
        // At this point "next" pointer should be the location to insert
        // 3. Insertion

        if (this->root_ == nullptr) {  // Insertion special case: this is the very first node in this tree:
            // Node<Key, Value> new_node(keyValuePair.first, keyValuePair.second, nullptr);
            Node<Key, Value>* new_node = new Node<Key, Value>(keyValuePair.first, keyValuePair.second, nullptr);
            this->root_ = new_node;

        } else {  // Insertion general case: this is the NOT the first node in this tree:
            Node<Key, Value>* new_node = new Node<Key, Value>(keyValuePair.first, keyValuePair.second, locator);
            if (set_left == true) {           // new node is a left child
                locator->setLeft(new_node);   // parent now points to left child accordingly
            } else {                          // new node is a right child
                locator->setRight(new_node);  // parent now points to left child accordingly
            }
        }
    }
}

/**
 * A remove method to remove a specific key from a Binary Search Tree.
 * The tree may not remain balanced after removal.
 */
template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::remove(const Key& key) {
    // Implemented by Simon
    // NO NEED TO MAINTAIN BALANCE
    Node<Key, Value>* search_result = internalFind(key);
    if (search_result != nullptr) {  // The target node does exist
        if ((search_result->getLeft() != nullptr)
            && (search_result->getRight() != nullptr)) {                         // Target node has TWO children
            Node<Key, Value>* in_order_pred = this->predecessor(search_result);  // Find the in-order predessesor
            this->nodeSwap(search_result, in_order_pred);                        // Swap target with its in-order pred

            // Note that now search_result should either have 0 child or 1 child
            if ((search_result->getLeft() != nullptr)
                && (search_result->getRight() == nullptr)) {  // search_result still has a left child to deal with
                Node<Key, Value>* replacement = search_result->getLeft();

                this->nodeSwap(search_result, replacement);  // promote that left child to search_result's position
                // Now initiate deletion!
                replacement->setLeft(nullptr);  // Take care of the parent
                delete search_result;
            } else if (
                    (search_result->getLeft() == nullptr)
                    && (search_result->getRight() != nullptr)) {  // search_result still has a right child to deal with
                Node<Key, Value>* replacement = search_result->getRight();

                this->nodeSwap(search_result, replacement);  // promote that left child to search_result's position
                // Now initiate deletion!
                replacement->setRight(nullptr);  // Take care of the parent
                delete search_result;
            } else {  // search_result is a leaf node, so we simply remove it
                this->adoption(search_result->getParent(), nullptr, search_result);
                delete search_result;
            }
        } else if ((search_result->getLeft() != nullptr) && (search_result->getRight() == nullptr)) {  // Target node
                                                                                                       // has ONE LEFT
                                                                                                       // children
            Node<Key, Value>* replacement = search_result->getLeft();
            this->nodeSwap(search_result, replacement);  // promote that left child to search_result's position
            // Now initiate deletion!
            replacement->setLeft(nullptr);  // Take care of the parent
            delete search_result;
        } else if ((search_result->getLeft() == nullptr) && (search_result->getRight() != nullptr)) {  // Target node
                                                                                                       // has ONE RIGHT
                                                                                                       // children
            Node<Key, Value>* replacement = search_result->getRight();

            this->nodeSwap(search_result, replacement);  // promote that left child to search_result's position
            // Now initiate deletion!
            replacement->setRight(nullptr);  // Take care of the parent
            delete search_result;
        } else {  // Target node has NO children
            if (search_result
                == (this->root_)) {  // We're deleting the root of this tree AND this tree has no other nodes
                delete search_result;
                this->root_ = nullptr;
            } else {
                this->adoption(search_result->getParent(), nullptr, search_result);
                delete search_result;
            }
        }
    }
    // The target node doesn't exist, we do NOTHING
}

template<class Key, class Value>
Node<Key, Value>* BinarySearchTree<Key, Value>::predecessor(Node<Key, Value>* current) {
    // Implemented by Simon
    // ONLY USE THIS FUNCTION ON A NODE THAT HAS *LEFT* CHILD
    Node<Key, Value>* predecessor = nullptr;  // initializing the predecessor pointer
    Node<Key, Value>* left_child = current->getLeft();
    Node<Key, Value>* next = nullptr;  // used to trace down the tree

    if (left_child->getRight() == nullptr) {  // If left child's right child DOESN'T exists:
        predecessor = left_child;             // Predecessor is the left child ITSELF.
        return predecessor;
    } else {  // If left child's right child exists:
        next = left_child->getRight();
        while (next != nullptr) {  // Predecessor is the right-most child of the left child
            predecessor = next;
            next = next->getRight();  // updating next pointer
        }
        return predecessor;
    }
}

/**
 * A method to remove all contents of the tree and
 * reset the values in the tree for use again.
 */
template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::clear() {
    // Implemented by Simon
    if (this->empty() == false) {  // deletion is necessary since the tree is not empty
        this->deletion(this->root_);
    }
    // Tree is already empty, refrain from deletion
}

/**
 * A helper function to find the smallest node in the tree.
 */
template<typename Key, typename Value>
Node<Key, Value>* BinarySearchTree<Key, Value>::getSmallestNode() const {
    // Implemented by Simon

    if (this->root_ == nullptr) {  // if there's no node in the tree, return a null pointer
        return nullptr;
    } else {
        Node<Key, Value>* next = this->root_;
        Node<Key, Value>* now = this->root_;
        while (next != nullptr) {
            now = next;
            next = now->getLeft();
        }
        // At this point we know that the left most node in the tree has pointer "now"
        return now;  // This pointer should point to the smallest node
    }
}

/**
 * Helper function to find a node with given key, k and
 * return a pointer to it or NULL if no item with that key
 * exists
 */
template<typename Key, typename Value>
Node<Key, Value>* BinarySearchTree<Key, Value>::internalFind(const Key& key) const {
    // Implemented by Simon
    Node<Key, Value>* now = (this->root_);  // We need to start searching from the root
    Node<Key, Value>* next = (this->root_);
    Node<Key, Value>* result = nullptr;      // Initializing a variable for containing the search result
    while (next != nullptr) {                // the next pointer is not null
        now = next;                          // We're now examining a new location
        if (key > (now->getKey())) {         // If our key is greater than this key
            next = (now->getRight());        // We should traverse the RIGHT child in the next iteration
        } else if (key < (now->getKey())) {  // If our key is less than this key
            next = (now->getLeft());         // We should traverse the LEFT child in the next iteration
        } else {                             // We've found the key's location!
            result = now;
            break;
        }
    }
    // At this point the search is over.
    if (result != nullptr) {  // Target is successfully found
        return result;
    } else {  // Target is not found in this BST
        return nullptr;
    }
}

/**
 * Return true iff the BST is balanced.
 */
template<typename Key, typename Value>
bool BinarySearchTree<Key, Value>::isBalanced() const {
    // Implemented by Simon
    // this function calls a RECURSIVE HELPTER function that checks if the left and right subtrees are balanced
    bool balanced = true;
    int height = this->balance(this->root_, balanced);
    height = 0;  // height is only used to catch the result of the recursive function's return statement, please ignore
    return balanced;
}

template<typename Key, typename Value>
int BinarySearchTree<Key, Value>::height(
        Node<Key, Value>* root)  // recursive helper function that return the height of a given node
{
    if (root == nullptr) {  // base case
        return 0;           // This is not a valid node, so it has no height
    } else {
        int left_height = 0;
        int right_height = 0;
        left_height = this->height(root->getLeft());    // Get the height of its left child
        right_height = this->height(root->getRight());  // Get the height of its right child
        if (left_height > right_height) {               // left height is greater
            return (1 + left_height);
        } else if (right_height > left_height) {  // right height is greater
            return (1 + right_height);
        } else {  // both heights are the same
            return (1 + left_height);
        }
    }
}

template<typename Key, typename Value>
int BinarySearchTree<Key, Value>::balance(Node<Key, Value>* root, bool& children_balanced)
        const  // An upgraded version of the above function with the ability to check if a node's two children are
               // balanced
{
    if (root == nullptr) {  // base case
        return 0;           // This is not a valid node, so it has no height
    } else {
        int left_height = 0;
        int right_height = 0;
        bool left_balance = true;
        bool right_balance = true;
        left_height
                = this->balance(root->getLeft(), left_balance);  // Get the height and balance status of its left child
        right_height = this->balance(
                root->getRight(), right_balance);  // Get the height and balance status of its right child
        if (left_height > right_height) {          // left height is greater
            if ((left_height - right_height)
                > 1) {  // Unbalance Scenario 1: unbalance situation happened on this exact node
                children_balanced = false;
            }
            if ((left_balance == false)
                || (right_balance == false)) {  // Unbalance Scenario 2: unbalance situation happened somewhere down
                                                // this node's subtree (or subtrees)
                children_balanced = false;
            }
            return (1 + left_height);
        } else if (right_height > left_height) {  // right height is greater
            if ((right_height - left_height)
                > 1) {  // Unbalance Scenario 1: unbalance situation happened on this exact node
                children_balanced = false;
            }
            if ((left_balance == false)
                || (right_balance == false)) {  // Unbalance Scenario 2: unbalance situation happened somewhere down
                                                // this node's subtree (or subtrees)
                children_balanced = false;
            }
            return (1 + right_height);
        } else {  // both heights are the same
            // Unbalance Scenario 1 is not possible in this case
            if ((left_balance == false)
                || (right_balance == false)) {  // Unbalance Scenario 2: unbalance situation happened somewhere down
                                                // this node's subtree (or subtrees)
                children_balanced = false;
            }
            return (1 + left_height);
        }
    }
}

template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::deletion(Node<Key, Value>* root) {

    if ((root->getLeft() == nullptr) && (root->getRight() == nullptr)) {  // This node is a leaf node
        // Perform deletion:
        if ((root->getParent()) == nullptr) {  // Special case: This is the root of the tree
            delete root;
            this->root_ = nullptr;
        } else {                                           // Common case: This is not the root of the tree
            if ((root->getParent())->getLeft() == root) {  // target is the left child of its parent
                (root->getParent())->setLeft(nullptr);     // Take care of the parent
                delete root;
            } else {                                     // target is the right child of its parent
                (root->getParent())->setRight(nullptr);  // Take care of the parent
                delete root;
            }
        }
    } else {  // This node is NOT a leaf node, which means we must delete its child or children first before deleting
              // this particular node.
        if (root->getLeft() != nullptr) {  // This node has a left child
            this->deletion(root->getLeft());
        }
        if (root->getRight() != nullptr) {  // This node has a right child
            this->deletion(root->getRight());
        }
        this->deletion(root);
    }
}

template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::adoption(
        Node<Key, Value>* parent,
        Node<Key, Value>* new_child,
        Node<Key, Value>* old_child) {         // Special function for changing parent to aid nodeSwap
    if (parent != nullptr) {                   //
        if (old_child == parent->getLeft()) {  // left child is the one to be changed
            parent->setLeft(new_child);
        } else {  // right child is the one to be changed
            parent->setRight(new_child);
        }
    }
}

template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::nodeSwap(Node<Key, Value>* n1, Node<Key, Value>* n2) {
    if ((n1 == n2) || (n1 == NULL) || (n2 == NULL)) {
        return;
    }
    Node<Key, Value>* n1p = n1->getParent();
    Node<Key, Value>* n1r = n1->getRight();
    Node<Key, Value>* n1lt = n1->getLeft();
    bool n1isLeft = false;
    if (n1p != NULL && (n1 == n1p->getLeft()))
        n1isLeft = true;
    Node<Key, Value>* n2p = n2->getParent();
    Node<Key, Value>* n2r = n2->getRight();
    Node<Key, Value>* n2lt = n2->getLeft();
    bool n2isLeft = false;
    if (n2p != NULL && (n2 == n2p->getLeft()))
        n2isLeft = true;

    Node<Key, Value>* temp;
    temp = n1->getParent();
    n1->setParent(n2->getParent());
    n2->setParent(temp);

    temp = n1->getLeft();
    n1->setLeft(n2->getLeft());
    n2->setLeft(temp);

    temp = n1->getRight();
    n1->setRight(n2->getRight());
    n2->setRight(temp);

    if ((n1r != NULL && n1r == n2)) {
        n2->setRight(n1);
        n1->setParent(n2);
    } else if (n2r != NULL && n2r == n1) {
        n1->setRight(n2);
        n2->setParent(n1);

    } else if (n1lt != NULL && n1lt == n2) {
        n2->setLeft(n1);
        n1->setParent(n2);

    } else if (n2lt != NULL && n2lt == n1) {
        n1->setLeft(n2);
        n2->setParent(n1);
    }

    if (n1p != NULL && n1p != n2) {
        if (n1isLeft)
            n1p->setLeft(n2);
        else
            n1p->setRight(n2);
    }
    if (n1r != NULL && n1r != n2) {
        n1r->setParent(n2);
    }
    if (n1lt != NULL && n1lt != n2) {
        n1lt->setParent(n2);
    }

    if (n2p != NULL && n2p != n1) {
        if (n2isLeft)
            n2p->setLeft(n1);
        else
            n2p->setRight(n1);
    }
    if (n2r != NULL && n2r != n1) {
        n2r->setParent(n1);
    }
    if (n2lt != NULL && n2lt != n1) {
        n2lt->setParent(n1);
    }

    if (this->root_ == n1) {
        this->root_ = n2;
    } else if (this->root_ == n2) {
        this->root_ = n1;
    }
}

/**
 * Lastly, we are providing you with a print function,
   BinarySearchTree::printRoot().
   Just call it with a node to start printing at, e.g:
   this->printRoot(this->root_) // or any other node pointer

   It will print up to 5 levels of the tree rooted at the passed node,
   in ASCII graphics format.
   We hope it will make debugging easier!
  */

// include print function (in its own file because it's fairly long)
#include "print_bst.h"

/*
---------------------------------------------------
End implementations for the BinarySearchTree class.
---------------------------------------------------
*/

#endif
