# Homework 6

Folder Contents:

"bst.h" is a header file that contain codes pertaining to making a binary search tree.

"avlbst.h" is a header file that contain codes pertaining to making an AVL tree. It does so
by public inheritance from bst.h.

"print_bst.h" is the header file that enable printing the AVL tree for displaying purposes 

"counting.cpp" is the main cpp file that will handle the solving and printing of each word
that appeared in the input file and how many times that word has appeared. It is capable
of using either AVL tree or Hashtable to execute the aforementioned functionality.

"Hashtable.cpp" is the cpp file that contains the implementation of the methods that are
specified in Hashtable.h. More specifically, it implements a Hashtable, and allows user to
choose whether they want a debug mode, and whether they want linear probing, quadratic
probing, or double-hashing.

"Hashtable.h" the header file that specifies all the methods and member variables that my
implementation of Hashtable requires.

"Makefile" specify the details required for "make" command to work properly.

Important note: There will be several lines of warning after compilation. These warnings
are about some variables that are not used. Please ignore these warning because it should
not affect the normal performance of the program. The reason those variables are not used
is because I implemented updateHeight function such that it return a boolean value. In 
particular parts of the code I utilize this return statement to get more information 
regarding to the updating process.


Usage details:
- To compile floorplan, simply type "make" or "make counting" in the command line.
- To use counting, provide input, output file, and other specifications like below:
	./counting [input] [output] x d r
	Where:
	- [input] will be an input text file, which you will run your program on.
	- [output] will be an output text file, which you will store your results in.
	- x will be an integer with value 0, 1, 2, or 3. If x=0, linear probing used. If x=1,
	 quadratic probing used. If x=2, use double-hashing. If x=3, AVL Tree from HW4 will be
	 used.
	- d will be an integer with value 0 or 1. If d=0, a normal HashTable will be created. 
	If d=1, then a debug-mode HashTable will be created. This value is ignored if x=3.
	- r will be an integer that says how often to repeat the whole program. (This is useful
	 to measure the time when the input is small and the time is otherwise reported as 0.)


Output file format:
Data type
Size of input cases: (a number)
Total of 10 cycles took: (a number) seconds
Runtime per cycle: (a number) 
Runtime per operation: (a number) <-This is average time taken for each word to be processed

Item name and its number of occurence:
(word) (occurence of that word)


Report: 
- For all data shown below: 
	- I used AVL tree for comparison because, like the writeup said, it's more interesting.
	- I used 10 cycles to get a higher number for runtime so that it's
	easier for comparison.
	- If it's a Hashtable, I always avoid using debug mode to get a true sense on its 
	runtime.

- Experiment result:
Size of input case: 351
Data Type:					Runtime for 10 cycles:		Runtime for each cycle:
HashTable: Linear Probing	0.085195 seconds			0.0085195 seconds
HashTable: Quadratic Probing0.084277 seconds			0.0084277 seconds
HashTable: Double-Hashing	0.086695 seconds			0.0086695 seconds
AVL Tree					0.09889  seconds			0.009889  seconds

Size of input case: 3696
Data Type:					Runtime for 10 cycles:		Runtime for each cycle:
HashTable: Linear Probing	0.467028 seconds			0.0467028 seconds
HashTable: Quadratic Probing0.469833 seconds			0.0469833 seconds
HashTable: Double-Hashing	0.484456 seconds			0.0484456 seconds
AVL Tree					0.514192 seconds			0.0514192 seconds

Size of input case: 31946
Data Type:					Runtime for 10 cycles:		Runtime for each cycle:
HashTable: Linear Probing	2.31991  seconds			0.231991  seconds
HashTable: Quadratic Probing2.16007  seconds			0.216007  seconds
HashTable: Double-Hashing	2.2094   seconds			0.22094   seconds
AVL Tree					2.34037  seconds			0.234037  seconds

- Analysis:

	- Firstly, it's obvious that AVL tree take longer runtime in general compared to Hashtable.

	- However, it's surprising to me that the difference between AVL tree and Hashtable is so
	small, especially when input cases gets larger. This is, I believe, due to the linear time
	taken for the Hashtable to parse through the entire table to find every element and rehash
	them to a new location. This step is not taken by AVL tree, which doesn't need to reallocate
	its size when adding, and uses binary search tree (log(n) time)instead.
	
	- Another reason why Hashtable takes so long might be attributed to the high number of
	modulo calculation that it needs to do when hashing. This effect can be seen from the
	significantly higher runtime of double-hashing, which require two hash functions, in 
	input cases of size 351 and 3696.
	


