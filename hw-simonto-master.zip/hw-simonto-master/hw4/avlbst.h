#ifndef RBBST_H
#define RBBST_H

#include "bst.h"
#include <algorithm>
#include <cstdlib>
#include <exception>
#include <iostream>

struct KeyError {};

/**
 * A special kind of node for an AVL tree, which adds the height as a data member, plus
 * other additional helper functions. You do NOT need to implement any functionality or
 * add additional data members or helper functions.
 */
template<typename Key, typename Value>
class AVLNode : public Node<Key, Value> {
public:
    // Constructor/destructor.
    AVLNode(const Key& key, const Value& value, AVLNode<Key, Value>* parent);
    virtual ~AVLNode();

    // Getter/setter for the node's height.
    int getHeight() const;
    void setHeight(int height);

    // Getters for parent, left, and right. These need to be redefined since they
    // return pointers to AVLNodes - not plain Nodes. See the Node class in bst.h
    // for more information.
    virtual AVLNode<Key, Value>* getParent() const override;
    virtual AVLNode<Key, Value>* getLeft() const override;
    virtual AVLNode<Key, Value>* getRight() const override;

protected:
    int height_;
};

/*
  -------------------------------------------------
  Begin implementations for the AVLNode class.
  -------------------------------------------------
*/

/**
 * An explicit constructor to initialize the elements by calling the base class constructor and setting
 * the color to red since every new node will be red when it is first inserted.
 */
template<class Key, class Value>
AVLNode<Key, Value>::AVLNode(const Key& key, const Value& value, AVLNode<Key, Value>* parent)
        : Node<Key, Value>(key, value, parent), height_(1) {}

/**
 * A destructor which does nothing.
 */
template<class Key, class Value>
AVLNode<Key, Value>::~AVLNode() {}

/**
 * A getter for the height of a AVLNode.
 */
template<class Key, class Value>
int AVLNode<Key, Value>::getHeight() const {
    return height_;
}

/**
 * A setter for the height of a AVLNode.
 */
template<class Key, class Value>
void AVLNode<Key, Value>::setHeight(int height) {
    height_ = height;
}

/**
 * An overridden function for getting the parent since a static_cast is necessary to make sure
 * that our node is a AVLNode.
 */
template<class Key, class Value>
AVLNode<Key, Value>* AVLNode<Key, Value>::getParent() const {
    return static_cast<AVLNode<Key, Value>*>(this->parent_);
}

/**
 * Overridden for the same reasons as above.
 */
template<class Key, class Value>
AVLNode<Key, Value>* AVLNode<Key, Value>::getLeft() const {
    return static_cast<AVLNode<Key, Value>*>(this->left_);
}

/**
 * Overridden for the same reasons as above.
 */
template<class Key, class Value>
AVLNode<Key, Value>* AVLNode<Key, Value>::getRight() const {
    return static_cast<AVLNode<Key, Value>*>(this->right_);
}

/*
  -----------------------------------------------
  End implementations for the AVLNode class.
  -----------------------------------------------
*/

template<class Key, class Value>
class AVLTree : public BinarySearchTree<Key, Value> {
public:
    virtual void insert(const std::pair<const Key, Value>& new_item);  // TODO
    virtual void remove(const Key& key);                               // TODO
protected:
    virtual void nodeSwap(AVLNode<Key, Value>* n1, AVLNode<Key, Value>* n2);

    // Add helper functions here

    bool updateHeight(AVLNode<Key, Value>* this_node);
    bool isLeftChild(AVLNode<Key, Value>* parent, AVLNode<Key, Value>* this_node);
    void rotateLeft(AVLNode<Key, Value>* this_node, AVLNode<Key, Value>* right_child);
    void rotateRight(AVLNode<Key, Value>* this_node, AVLNode<Key, Value>* left_child);
    void insertFix(AVLNode<Key, Value>* parent, AVLNode<Key, Value>* this_node);
    void removeFix(AVLNode<Key, Value>* this_node);
};

template<class Key, class Value>
void AVLTree<Key, Value>::insert(const std::pair<const Key, Value>& new_item) {
    // Implemented by Simon
    if (this->root_ == nullptr) {  // This tree is empty
        // Node<Key, Value>* new_node = new
        AVLNode<Key, Value>* new_avl_root = new AVLNode<Key, Value>(new_item.first, new_item.second, nullptr);
        this->root_ = new_avl_root;
    } else {
        Node<Key, Value>* search_result = this->internalFind(new_item.first);
        if (search_result != nullptr) {                // this key exists prior to this insertion
            search_result->setValue(new_item.second);  // We just have to simply update the value of that pair
        } else {
            AVLNode<Key, Value>* locator
                    = static_cast<AVLNode<Key, Value>*>(this->root_);  // We need to start from the root
            AVLNode<Key, Value>* next = static_cast<AVLNode<Key, Value>*>(
                    this->root_);  // We also need to keep track of the next pointer to search

            bool set_left = true;  // Assume our new node will be a left child, will change according to actual scenario
            while (next != nullptr) {                      // the next pointer is not null
                locator = next;                            // We're now examining a new location
                if (new_item.first > locator->getKey()) {  // If our key is greater than this key
                    next = locator->getRight();            // We should traverse the RIGHT child in the next iteration
                    set_left = false;
                } else if (new_item.first < locator->getKey()) {  // If our key is less than this key
                    next = locator->getLeft();  // We should traverse the LEFT child in the next iteration
                    set_left = true;
                }
            }

            AVLNode<Key, Value>* new_avl_node = new AVLNode<Key, Value>(new_item.first, new_item.second, locator);
            if (set_left == true) {               // new node is a left child
                locator->setLeft(new_avl_node);   // parent now points to left child accordingly
            } else {                              // new node is a right child
                locator->setRight(new_avl_node);  // parent now points to left child accordingly
            }

            if ((locator->getHeight()) == 1) {           // h(p) = 1, we need to call insert-fix
                locator->setHeight(2);                   // update h(p) to 2
                this->insertFix(locator, new_avl_node);  // Fix the heights of grandparents
            }
            // h(p) = 2, done!
        }
    }
}

template<class Key, class Value>
void AVLTree<Key, Value>::remove(const Key& key) {
    // Implemented by Simon
    AVLNode<Key, Value>* target = static_cast<AVLNode<Key, Value>*>(
            this->internalFind(key));                         // Find the target to remove via internal find
    if (target != nullptr) {                                  // This target DOES exist in the tree
        AVLNode<Key, Value>* parent = target->getParent();    // Get the parent of target before actual deletion
        if (parent == nullptr) {                              // This is a root node
            this->BinarySearchTree<Key, Value>::remove(key);  // Delete the target from the tree
            this->removeFix(static_cast<AVLNode<Key, Value>*>(this->root_));  // Patch the tree
        } else {

            bool replacerAtLeft = isLeftChild(parent, target);
            this->BinarySearchTree<Key, Value>::remove(key);  // Delete the target from the tree

            AVLNode<Key, Value>* replacer
                    = nullptr;  // This pointer point to the node that replaced target's position in the tree

            if (replacerAtLeft == true) {
                if (parent->getLeft() != nullptr) {
                    replacer = parent->getLeft();
                }
            }
            if (replacerAtLeft == false) {
                if (parent->getRight() != nullptr) {
                    replacer = parent->getRight();
                }
            }

            if (replacer != nullptr) {  // There exists a node such that it replaces target's position in tree
                bool catcher = this->updateHeight(replacer);  // Update the height of replacer
                catcher = false;                              // Junk variable

                int left_height = 0;  // Default height is 0
                int right_height = 0;
                if (replacer->getLeft() != nullptr) {
                    left_height = (replacer->getLeft())->getHeight();
                }
                if (replacer->getRight() != nullptr) {
                    right_height = (replacer->getRight())->getHeight();
                }

                // Now we check if grandparent is balanced
                if (abs(left_height - right_height) > 1) {  // Unbalanced
                    this->removeFix(
                            replacer);  // The replacer is already unbalanced, so we have to removefix, here and now.
                } else {
                    this->removeFix(parent);  // The replacer is balanced, but what about its parent?
                }

            } else {
                this->removeFix(parent);  // The replacer is vacuously balanced
            }
        }
    }
}

template<class Key, class Value>
void AVLTree<Key, Value>::nodeSwap(AVLNode<Key, Value>* n1, AVLNode<Key, Value>* n2) {
    BinarySearchTree<Key, Value>::nodeSwap(n1, n2);
    int tempH = n1->getHeight();
    n1->setHeight(n2->getHeight());
    n2->setHeight(tempH);
}

template<class Key, class Value>
bool AVLTree<Key, Value>::updateHeight(AVLNode<Key, Value>* this_node) {
    int max_child_h = 0;
    if ((this_node->getLeft()) != nullptr) {
        max_child_h = (this_node->getLeft())->getHeight();  // Assume the left node has the largest height
        if ((this_node->getRight()) != nullptr) {
            if (((this_node->getRight())->getHeight()) > max_child_h) {  // Verify the above assumption
                max_child_h = (this_node->getRight())->getHeight();      // Assumption falsified
            }
        }
    } else {
        if ((this_node->getRight()) != nullptr) {
            max_child_h = (this_node->getRight())->getHeight();
        }
    }

    int calculated_h = max_child_h + 1;

    // Two conditions to return false (meaning no need to continue calling this function):
    // 1. Computed height is the same as existing height.
    // 2. this_node is the root of the entire tree.

    if (calculated_h == (this_node->getHeight())) {  // Is the calculated height the same as the existing height
        return false;                                // Condition 1
    } else {
        if ((this_node->getParent()) == nullptr) {  // this_node is the root of the tree
            this_node->setHeight(calculated_h);     // Update the root's height
            return false;                           // Condition 2
        } else {                                    // this_node is NOT the root of the tree
            this_node->setHeight(calculated_h);     // Update this normal node's height
            return true;
        }
    }
}

template<class Key, class Value>
bool AVLTree<Key, Value>::isLeftChild(
        AVLNode<Key, Value>* parent,
        AVLNode<Key, Value>* this_node)  // Determines if this_node is a LEFT child of its parent
{
    if (parent->getLeft() == this_node) {
        return true;
    } else {
        return false;
    }
}

template<class Key, class Value>
void AVLTree<Key, Value>::rotateLeft(
        AVLNode<Key, Value>* this_node, AVLNode<Key, Value>* right_child)  // NO CHANGE OF HEIGHT IS DONE HERE!!!
{
    if (this_node == this->root_) {  // Special case: this_node is the root of the whole tree
        this->root_ = right_child;   // Update the root to the right child, who will be the new root
    }

    AVLNode<Key, Value>* new_parent = right_child;
    if ((this_node->getParent()) != nullptr) {                       // If this node is NOT the root of AVL tree
        if (this->isLeftChild(this_node->getParent(), this_node)) {  // this node is the left child of its parent
            (this_node->getParent())->Node<Key, Value>::setLeft(new_parent);  // Take care of parent of our subtree
        } else {  // this node is the right child of its parent
            (this_node->getParent())->Node<Key, Value>::setRight(new_parent);  // Take care of parent of our subtree
        }
    }
    // If this node is the root of AVL tree, nothing needs to be done at this point, because a root doesn't have a
    // parent to take care of

    new_parent->Node<Key, Value>::setParent(this_node->getParent());  // Child, come and meet your new parent!
    // Now we have to address the orphan crisis :(
    AVLNode<Key, Value>* orphan = right_child->getLeft();  // Our orphan is found
    this_node->Node<Key, Value>::setRight(orphan);         // Now we need to get this orphan to their new parent!
    if (orphan != nullptr) {                               // if there's a orphan
        orphan->Node<Key, Value>::setParent(this_node);    // Say hello to your adopt parent!
    }

    right_child->Node<Key, Value>::setLeft(this_node);   // Now this node can be its original right child's left child!
    this_node->Node<Key, Value>::setParent(new_parent);  // Say hello to your new parent!
}

template<class Key, class Value>
void AVLTree<Key, Value>::rotateRight(AVLNode<Key, Value>* this_node, AVLNode<Key, Value>* left_child) {
    if (this_node == this->root_) {  // Special case: this_node is the root of the whole tree
        this->root_ = left_child;    // Update the root to the left child, who will be the new root
    }

    AVLNode<Key, Value>* new_parent = left_child;
    if ((this_node->getParent()) != nullptr) {                       // If this node is NOT the root of AVL tree
        if (this->isLeftChild(this_node->getParent(), this_node)) {  // this node is the left child of its parent
            (this_node->getParent())->Node<Key, Value>::setLeft(new_parent);  // Take care of parent of our subtree
        } else {  // this node is the left child of its parent
            (this_node->getParent())->Node<Key, Value>::setRight(new_parent);  // Take care of parent of our subtree
        }
    }
    // If this node is the root of AVL tree, nothing needs to be done at this point, because a root doesn't have a
    // parent to take care of

    new_parent->Node<Key, Value>::setParent(this_node->getParent());  // Child, come and meet your new parent!
    // Now we have to address the orphan crisis :(
    AVLNode<Key, Value>* orphan = left_child->getRight();  // Our orphan is found
    this_node->Node<Key, Value>::setLeft(orphan);          // Now we need to get this orphan to their new parent!
    if (orphan != nullptr) {                               // if there's a orphan
        orphan->Node<Key, Value>::setParent(this_node);    // Say hello to your adopt parent!
    }

    // static_cast<AVLNode<Key, Value>*>(this_node)

    left_child->Node<Key, Value>::setRight(this_node);   // Now this node can be its original right child's left child!
    this_node->Node<Key, Value>::setParent(new_parent);  // Say hello to your new parent!
}

template<class Key, class Value>
void AVLTree<Key, Value>::insertFix(AVLNode<Key, Value>* parent, AVLNode<Key, Value>* this_node) {

    if (parent == nullptr) {  // Base case 1: root node is reached
        return;
    } else if ((parent->getParent()) == nullptr) {  // Base case 2: root node is a node away
        return;
    } else {                                                     // Not base case 1:
        AVLNode<Key, Value>* grandparent = parent->getParent();  // Consider the grandparent of this_node
        bool catcher = this->updateHeight(grandparent);
        if ((catcher == false) && (grandparent->getParent() != nullptr)) {  // updateHeight's condition 1
            return;  // Base case 3: grandparent's height doesn't change
        } else {
            int left_height = 0;  // Default height is 0
            int right_height = 0;
            if (grandparent->getLeft() != nullptr) {
                left_height = (grandparent->getLeft())->getHeight();
            }
            if (grandparent->getRight() != nullptr) {
                right_height = (grandparent->getRight())->getHeight();
            }

            // Now we check if grandparent is balanced
            if (abs(left_height - right_height) > 1) {  // Unbalanced
                bool PLeftChildG
                        = this->isLeftChild(grandparent, parent);  // true if parent is the left child of grandparent
                bool NLeftChildP
                        = this->isLeftChild(parent, this_node);  // true if this_node is the left child of parent

                // Zig-Zig scenarios:
                if ((PLeftChildG == true) && (NLeftChildP == true)) {  // Left Zig-Zig
                    this->rotateRight(grandparent, parent);

                    // update the heights
                    bool keep_updating = true;
                    while (keep_updating == true) {
                        keep_updating = this->updateHeight(grandparent);
                    }
                    keep_updating = true;
                    while (keep_updating == true) {
                        keep_updating = this->updateHeight(parent);
                    }
                } else if ((PLeftChildG == false) && (NLeftChildP == false)) {  // Right Zig-Zig
                    this->rotateLeft(grandparent, parent);

                    // update the heights
                    bool keep_updating = true;
                    while (keep_updating == true) {
                        keep_updating = this->updateHeight(grandparent);
                    }
                    keep_updating = true;
                    while (keep_updating == true) {
                        keep_updating = this->updateHeight(parent);
                    }
                }

                // Zig-Zag scenarios:
                else if ((PLeftChildG == true) && (NLeftChildP == false)) {  // Left Zig - Right Zag
                    this->rotateLeft(parent, this_node);
                    this->rotateRight(grandparent, grandparent->getLeft());

                    // update the heights
                    bool keep_updating = true;

                    while (keep_updating == true) {
                        keep_updating = this->updateHeight(grandparent);
                    }
                    keep_updating = true;
                    while (keep_updating == true) {
                        keep_updating = this->updateHeight(parent);
                    }
                    keep_updating = true;
                    while (keep_updating == true) {
                        keep_updating = this->updateHeight(this_node);
                    }
                } else {  // Right Zig - Left Zag
                    this->rotateRight(parent, this_node);
                    this->rotateLeft(grandparent, grandparent->getRight());

                    // update the heights
                    bool keep_updating = true;

                    while (keep_updating == true) {
                        keep_updating = this->updateHeight(grandparent);
                    }
                    keep_updating = true;
                    while (keep_updating == true) {
                        keep_updating = this->updateHeight(parent);
                    }
                    keep_updating = true;
                    while (keep_updating == true) {
                        keep_updating = this->updateHeight(this_node);
                    }
                }
                // Done!
            } else {                                   // Balanced
                this->insertFix(grandparent, parent);  // Recursive step
            }
        }
    }
}

template<class Key, class Value>
void AVLTree<Key, Value>::removeFix(AVLNode<Key, Value>* this_node) {
    if (this_node == nullptr) {  // Base case 1: this node doesn't exist
        return;
    } else {

        bool catcher = this->updateHeight(this_node);

        int left_height = 0;  // Default height is 0
        int right_height = 0;
        if (this_node->getLeft() != nullptr) {
            left_height = (this_node->getLeft())->getHeight();
        }
        if (this_node->getRight() != nullptr) {
            right_height = (this_node->getRight())->getHeight();
        }

        // Now we check if grandparent is balanced
        if (abs(left_height - right_height) > 1) {  // Unbalanced
            AVLNode<Key, Value>* child;
            bool CisleftN;
            if (left_height > right_height) {   // left child is taller
                child = this_node->getLeft();   // We choose the left child
                CisleftN = true;                // Record the relationship between this_node and child
            } else {                            // right child is taller
                child = this_node->getRight();  // We choose the right child
                CisleftN = false;               // Record the relationship between this_node and child
            }

            left_height = 0;  // Default height is 0
            right_height = 0;
            if (child->getLeft() != nullptr) {
                left_height = (child->getLeft())->getHeight();
            }
            if (child->getRight() != nullptr) {
                right_height = (child->getRight())->getHeight();
            }

            AVLNode<Key, Value>* grandchild;
            bool GisleftC;
            if (left_height > right_height) {   // left child is taller
                grandchild = child->getLeft();  // We choose the left grandchild
                GisleftC = true;
            } else if (right_height > left_height) {  // right child is taller
                grandchild = child->getRight();       // We choose the right grandchild
                GisleftC = false;
            } else {  // both children have the SAME height
                // Provide preferential treatment for Zig-Zig scenario to break tie:
                if (CisleftN == true) {             // Child is the left child of this_node
                    grandchild = child->getLeft();  // We choose the left grandchild
                    GisleftC = true;
                } else {                             // Child is the right child of this_node
                    grandchild = child->getRight();  // We choose the right grandchild
                    GisleftC = false;
                }
            }

            // At this point we have the information we need for rotation

            AVLNode<Key, Value>* original_parent
                    = this_node->getParent();  // Record the address of this subtree's parent for later use

            // Zig-Zig scenarios:
            if ((CisleftN == true) && (GisleftC == true)) {  // Left Zig-Zig
                this->rotateRight(this_node, child);

                // update the heights
                bool junk_catcher = this->updateHeight(this_node);  // update h(n). junk_catcher is only used to
                                                                    // catching the return statement of updateHeight
                junk_catcher = this->updateHeight(child);           // update h(c).
                this->removeFix(original_parent);                   // Fix the height of the parent of this subtree

            } else if ((CisleftN == false) && (GisleftC == false)) {  // Right Zig-Zig
                this->rotateLeft(this_node, child);

                // update the heights
                bool junk_catcher = this->updateHeight(this_node);  // update h(n). junk_catcher is only used to
                                                                    // catching the return statement of updateHeight
                junk_catcher = this->updateHeight(child);           // update h(c).
                this->removeFix(original_parent);                   // Fix the height of the parent of this subtree
            }

            // Zig-Zag scenarios:
            else if ((CisleftN == true) && (GisleftC == false)) {  // Left Zig - Right Zag
                this->rotateLeft(child, grandchild);
                this->rotateRight(this_node, this_node->getLeft());

                // update the heights
                bool junk_catcher = this->updateHeight(this_node);  // update h(n). junk_catcher is only used to
                                                                    // catching the return statement of updateHeight
                junk_catcher = this->updateHeight(child);           // update h(c).
                junk_catcher = this->updateHeight(grandchild);      // update h(g).
                this->removeFix(original_parent);                   // Fix the height of the parent of this subtree
            } else {                                                // Right Zig - Left Zag
                this->rotateRight(child, grandchild);
                this->rotateLeft(this_node, this_node->getRight());
                // update the heights
                bool junk_catcher = this->updateHeight(this_node);  // update h(n). junk_catcher is only used to
                                                                    // catching the return statement of updateHeight
                junk_catcher = this->updateHeight(child);           // update h(c).
                junk_catcher = this->updateHeight(grandchild);      // update h(g).

                this->removeFix(original_parent);  // Fix the height of the parent of this subtree
            }
            // Done!

        } else {  // Balanced

            if ((catcher == false) && ((this_node->getParent()) != nullptr)) {  // updateHeight's condition 1
                return;  // Base case 2: grandparent's height doesn't change
            } else {     // this_node's height is changed
                bool junk_catcher2 = this->updateHeight(this_node);
                junk_catcher2 = false;  // like its brother, this variable has no use in out situation, setting to false
                                        // to avoid accidents
                this->removeFix(this_node->getParent());
            }
        }
    }
}

#endif
