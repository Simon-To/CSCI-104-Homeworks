# Homework 5

Files included in this folder (excluding this file):

bayes.cpp: Contains code that read in a train and classify file, then output the result
to the specified output file.

Makefile: Allow user to simply type "make" to compile bayes.cpp executable


Usage details:
- To compile bayes, simply type "make" in the command line.
- To use bayes, provide train, classify and output file like below: (This is IDENTICAL to
the specified command input on homework writeup)
	./bayes train.txt classify.txt output.txt


Important note: As recommended by TAs, to expedite the grading process, I implemented the 
following features in my bayes.cpp that are ADDITIONAL to what's specified in the writeup:

1. Duplicates in the same line ARE ignored, and this applies to BOTH train.txt and 
classify.txt.
2. The end of the output file does NOT contain an extra empty line. To wit, the file ends
in the last line of output.
