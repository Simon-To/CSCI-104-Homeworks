#include "ulliststr.h"

using namespace std;

#include <curricula.hpp>

extern "C" {
void list_push_back(ULListStr& list, const string& value) { list.push_back(value); }

void list_push_front(ULListStr& list, const string& value) { list.push_front(value); }

void list_get(const ULListStr& list, size_t index) { list.get(index); }

void list_pop_back(ULListStr& list) { list.pop_back(); }

void list_pop_front(ULListStr& list) { list.pop_front(); }
}

TESTS_BEGIN

if (argc < 3) {
    return 3;
}

ULListStr list;
size_t size = stoul(argv[2]);
for (size_t i = 0; i < size; ++i) {
    list.push_back("a");
}

TEST(push_back) {
    list_push_back(list, "a");
    PASS;
}

TEST(push_front) {
    list_push_front(list, "a");
    PASS;
}

TEST(get) {
    list_get(list, size / 2);
    PASS;
}

TEST(pop_back) {
    list_pop_back(list);
    PASS;
}

TEST(pop_front) {
    list_pop_front(list);
    PASS;
}

TESTS_END
