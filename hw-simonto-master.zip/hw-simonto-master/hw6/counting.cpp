//
//  main.cpp
//  Hashtable
//
//  Created by Simon To on 26/4/21.
//

#include "Hashtable.h"
#include "avlbst.h"
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

std::string removeSpecialChar(std::string s);

std::string changeToLower(std::string s);

int main(int argc, const char* argv[]) {
    srand((unsigned int)time(0));  // seeding the pseudo-random number generator IMPORTANT, PLEASE DON'T DELETE!!

    // Start of timer initialization
    clock_t start;
    double duration;
    // End of timer initialization

    if (argc < 6) {
        std::cout << "Please remember to enter the [input] [output] x d r, and try again!" << std::endl;
        return 0;
    }

    std::ifstream fin(argv[1]);
    if (!fin) {
        std::cerr << "error\n";
        return 1;
    }
    std::vector<std::string> input_testing;

    std::string line;
    while (std::getline(fin, line)) {
        std::istringstream iss(line);
        while (iss) {
            std::string a;
            iss >> a;
            std::string alpha_only = removeSpecialChar(a);
            std::string lower_only = changeToLower(alpha_only);
            if (!(lower_only.empty())) {
                input_testing.push_back(lower_only);
            }
        }
    }

    fin.close();

    int desired_operation = atoi(argv[3]);

    int repetition = atoi(argv[5]);

    int operation_cycle = 0;

    start = clock();

    if (desired_operation < 3) {  // Using Hashtable
        while (operation_cycle < repetition) {
            bool debug_mode = (bool)(atoi(argv[4]));
            Hashtable hashbrown(debug_mode, desired_operation);

            int vector_size = ((int)(input_testing.size()));
            for (int i = 0; i < vector_size; ++i) {
                hashbrown.add(input_testing[i]);
            }

            operation_cycle += 1;

            std::ofstream ofile(argv[2]);

            duration = (clock() - start) / ((double)CLOCKS_PER_SEC);

            std::string modes[3] = {"Linear Probing", "Quadratic Probing", "Double-Hashing"};

            ofile << "HashTable: " << modes[desired_operation] << std::endl;

            ofile << "Size of input cases: " << ((int)(input_testing.size())) << std::endl;

            ofile << "Total of " << repetition << " cycles took: " << duration << " seconds" << std::endl;

            ofile << "Runtime per cycle: " << (duration / repetition) << std::endl;

            ofile << "Runtime per operation: " << (duration / repetition) / ((int)(input_testing.size())) << std::endl;

            ofile << std::endl;

            ofile << "Item name and its number of occurence: " << std::endl;

            hashbrown.reportAll(ofile);

            ofile.close();
        }
    } else {
        if (desired_operation == 3) {  // Using AVLtree
            while (operation_cycle < repetition) {
                AVLTree<std::string, int> avlbrown;

                int vector_size = ((int)(input_testing.size()));
                for (int i = 0; i < vector_size; ++i) {
                    AVLTree<std::string, int>::iterator search_result = avlbrown.find(input_testing[i]);

                    if (search_result == avlbrown.end()) {  // This is a new member
                        std::pair<std::string, int> new_item;
                        new_item.first = input_testing[i];
                        new_item.second = 1;
                        avlbrown.insert(new_item);
                    } else {  // This is an old member, increment its value
                        search_result->second += 1;
                    }
                }

                operation_cycle += 1;

                std::ofstream ofile(argv[2]);

                duration = (clock() - start) / ((double)CLOCKS_PER_SEC);

                ofile << "AVL Tree" << std::endl;

                ofile << "Size of input cases: " << ((int)(input_testing.size())) << std::endl;

                ofile << "Total of " << repetition << " cycles took: " << duration << " seconds" << std::endl;

                ofile << "Runtime per cycle: " << (duration / repetition) << std::endl;

                ofile << "Runtime per operation: " << (duration / repetition) / ((int)(input_testing.size()))
                      << std::endl;

                ofile << std::endl;

                ofile << "Item name and its number of occurence: " << std::endl;

                AVLTree<std::string, int>::iterator it;
                for (it = avlbrown.begin(); it != avlbrown.end(); ++it) {
                    ofile << it->first << " " << it->second << std::endl;
                }

                ofile.close();
            }
        } else {
            std::cout << "Please ensure that you enter 0 to 3 (inclusive) and try again!" << std::endl;
            return 0;
        }
    }
    return 0;
}

std::string removeSpecialChar(std::string s) {
    int j = 0;
    for (int i = 0; i < ((int)(s.size())); i++) {
        if ((s[i] >= 'A' && s[i] <= 'Z') || (s[i] >= 'a' && s[i] <= 'z')) {
            s[j] = s[i];
            j++;
        }
    }
    return (s.substr(0, j));
}

std::string changeToLower(std::string s) {
    for (int i = 0; i < ((int)(s.size())); i++) {
        if ((s[i] >= 'A') && (s[i] <= 'Z')) {
            s[i] += 32;
        }
    }
    return s;
}
