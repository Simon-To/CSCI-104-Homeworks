//
//  split_test.cpp
//
//
//  Created by Simon To on 31/1/21.
//

#include "split.h"
#include <cstddef>
#include <iostream>

/* Add a prototype for a helper function here if you need */

using namespace std;

void split(Node*& in, Node*& odds, Node*& evens) {

    if (in != NULL) {
        if (in->value % 2 == 0) {  // if the element next-up is even
            evens = in;
            evens->next = in->next;
            // delete in;
            split(evens->next, odds, evens->next);
            if (evens->next != NULL
                && (evens->next->value % 2 == 1)) {  // Double check if things are going the right way.
                evens->next = NULL;
            }
        } else if (in->value % 2 == 1) {  // if the element next-up is even
            odds = in;
            odds->next = in->next;
            // delete in;
            split(odds->next, odds->next, evens);
            if (odds->next != NULL
                && (odds->next->value % 2 == 0)) {  // Double check if things are going the right way.
                odds->next = NULL;
            }
        }
    } else {

        return;
    }
}

// helper function
void printList(Node* n) {
    while (n != NULL) {
        cout << n->value << " ";
        n = n->next;
    }
}

void deleteList(Node* n) {
    while (n != NULL) {
        Node* tempo = n->next;
        delete n;
        n = tempo;
    }
}

Node* ten_elements_LL() {
    Node* temp = nullptr;
    Node* result = new Node(0, NULL);
    Node* head = result;
    for (int i = 0; i < 50; i++) {
        result->value = i;
        temp = new Node(0, NULL);
        result->next = temp;
        result = result->next;
    }
    // delete temp;
    return head;
}

int main() {
    Node* my_ll = ten_elements_LL();

    printList(my_ll);
    cout << endl;

    Node* odds = NULL;
    Node* evens = NULL;
    split(my_ll, odds, evens);
    printList(odds);

    cout << endl;
    printList(evens);

    deleteList(odds);
    deleteList(evens);

    return 0;
}
