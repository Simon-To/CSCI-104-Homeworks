//
//  movie.cpp
//
//
//  Created by Simon To on 16/2/21.
//

#include "movie.h"

#include "product.h"
#include "util.h"
#include <iostream>
#include <sstream>
#include <string.h>

using namespace std;

Movie::Movie(
        const std::string category,
        const std::string name,
        double price,
        int qty,
        const std::string genre,
        const std::string rating)
        : Product(category, name, price, qty) {
    genre_ = genre;
    rating_ = rating;
}

Movie::~Movie() {}

/**
 * Returns the appropriate keywords that this product should be associated with
 */
std::set<std::string> Movie::keywords() const {
    std::set<std::string> key_words;

    std::set<std::string> parsed_name = parseStringToWords(name_);
    key_words.insert(parsed_name.begin(), parsed_name.end());

    key_words.insert(genre_);

    return key_words;
}

/**
 * Returns a string to display the product info for hits of the search
 */
std::string Movie::displayString() const {
    std::string info_display;

    info_display.append(name_);
    info_display.append("\n");
    info_display.append("Genre: ");
    info_display.append(genre_);
    info_display.append(" Rating: ");
    info_display.append(rating_);
    info_display.append("\n");
    std::ostringstream conv_price;
    conv_price << price_;
    std::string str_price = conv_price.str();
    info_display.append(str_price);
    info_display.append(" ");
    info_display.append(std::to_string(qty_));
    info_display.append(" left.");
    info_display.append("\n");

    return info_display;
}

/**
 * Outputs the product info in the database format
 */
void Movie::dump(std::ostream& os) const {
    os << "movie\n";
    os << name_;
    os << "\n";
    os << price_;
    os << "\n";
    os << qty_;
    os << "\n";
    os << genre_;
    os << "\n";
    os << rating_;
    os << "\n";
}

// Below are the member variable that we have:
