Homework 3 Programming Part

Student: Simon To
Student Email: simonto@usc.edu

Please use command "make" to make amazon executable
Type in "./amazon database.txt" to run

=====================================
Menu:
  AND term term ...
  OR term term ...
  ADD username search_hit_number
  VIEWCART username
  BUYCART username
  QUIT new_db_filename
====================================
