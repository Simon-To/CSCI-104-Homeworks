# Homework 4

floorplan.cpp produces a solution to the problem of putting several tiles within a
confined within a board. Please build

floorplan without avl.cpp is an ULTERNATIVE version designed for the situation where you 
find floorplan.cpp cannot function normally. PLEASE TRY floorplan.cpp first!

bst.h is a header file that contain codes pertaining to making a binary search tree.

avlbst.h is a header file that contain codes pertaining to making an AVL tree. It does so
by public inheritance from bst.h.

floor_input.txt floor_output.txt are input and output files I last used for testing. They
are just for demonstration purposes, feel free to ignore them.

Makefile specify the details required for "make" command to work properly.


Usage details:
- To compile floorplan, simply type "make" in the command line.
- To use floorplan, provide input and output file like below:
	./floorplan input.txt output.txt

Important note: There will be several lines of warning after compilation. These warnings
are about some variables that are not used. Please ignore these warning because it should
not affect the normal performance of the program. The reason those variables are not used
is because I implemented updateHeight function such that it return a boolean value. In 
particular parts of the code I utilize this return statement to get more information 
regarding to the updating process.
