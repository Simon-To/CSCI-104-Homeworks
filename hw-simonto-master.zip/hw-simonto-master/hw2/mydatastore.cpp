//
//  mydatastore.cpp
//
//
//  Created by Simon To on 17/2/21.
//

#include "mydatastore.h"

#include "datastore.h"
#include <stdio.h>

MyDataStore::~MyDataStore() {
    // std::set<Product*> all_products;
    // iterate over all_products to delete all the products
    std::set<Product*>::iterator product_it;
    for (product_it = all_products.begin(); product_it != all_products.end(); ++product_it) {
        delete (*product_it);
    }

    // std::map<std::string, User*> user_database;
    // iterate over user_databse to delete all the users
    std::map<std::string, User*>::iterator user_it;
    for (user_it = user_database.begin(); user_it != user_database.end(); ++user_it) {
        delete (user_it->second);
    }
}

/**
 * Adds a product to the data store
 */
void MyDataStore::addProduct(Product* p) {
    std::set<std::string> keyword_set = p->keywords();  // get the set of keywords from this product
    all_products.insert(p);
    std::set<std::string>::iterator it;
    for (it = keyword_set.begin(); it != keyword_set.end(); ++it) {
        if (product_database.find(*it) != product_database.end()) {
            // this keyword already contains at least one product*
            product_database.find(*it)->second.insert(p);
        } else {
            // this keyword doesn't exist in this database, we need to create one for it
            std::set<Product*> new_set_Products;
            new_set_Products.insert(p);
            product_database[*it] = new_set_Products;
            all_keywords.insert(*it);
        }
    }
}

/**
 * Adds a user to the data store
 */
void MyDataStore::addUser(User* u) { user_database[u->getName()] = u; }

/**
 * Performs a search of products whose keywords match the given "terms"
 *  type 0 = AND search (intersection of results for each term) while
 *  type 1 = OR search (union of results for each term)
 */
std::vector<Product*> MyDataStore::search(std::vector<std::string>& terms, int type) {
    if (terms.empty() == true) {  // No keywords entered, return an error message to remind the user
        std::cout << "Search failed: No keyword given." << std::endl;
        std::vector<Product*> empty_vector;  // return an empty vector is trigger "no results found"
        return empty_vector;
    } else {
        if (type == 0) {  // perform an AND search
            // convert string vector to a string set
            std::vector<std::string> my_terms = terms;
            std::set<std::string> search_words(my_terms.begin(), my_terms.end());

            // use setIntersection to get string set of matches
            std::set<std::string> matches
                    = setIntersection(search_words, all_keywords);  // find all the keywords required

            // construct a Product* vector from the set of matches
            std::set<Product*> temp_search_result
                    = product_database.find(*matches.begin())->second;  // Product* set for the first keyword
            std::set<Product*> to_be_appended;
            std::set<std::string>::iterator it;
            for (it = ++matches.begin(); it != matches.end();
                 ++it) {  // starting from the second keyword, do intersection
                temp_search_result = setIntersection(temp_search_result, product_database.find(*it)->second);
            }

            std::vector<Product*> search_result{temp_search_result.begin(), temp_search_result.end()};

            // return that Product* vector
            return search_result;
        } else {  // perform an OR search
            // convert string vector to a string set
            std::vector<std::string> my_terms = terms;
            std::set<std::string> search_words(my_terms.begin(), my_terms.end());

            // use setIntersection to get string set of matches
            std::set<std::string> matches = setIntersection(search_words, all_keywords);

            // construct a Product* vector from the set of matches
            std::set<Product*> temp_search_result;
            std::set<Product*> to_be_appended;
            std::set<std::string>::iterator it;
            for (it = matches.begin(); it != matches.end(); ++it) {
                to_be_appended = product_database.find(*it)->second;
                temp_search_result.insert(to_be_appended.begin(), to_be_appended.end());
                to_be_appended.clear();
            }

            std::vector<Product*> search_result{temp_search_result.begin(), temp_search_result.end()};

            // return that Product* vector
            return search_result;
        }
    }
}

/**
 * Reproduce the database file from the current Products and User values
 */
void MyDataStore::dump(std::ostream& ofile) {
    ofile << "<products>\n";
    std::set<Product*>::iterator pro_it;
    for (pro_it = all_products.begin(); pro_it != all_products.end(); ++pro_it) {
        (*pro_it)->dump(ofile);
    }
    ofile << "</products>\n";
    ofile << "<users>\n";
    std::map<std::string, User*>::iterator use_it;
    for (use_it = user_database.begin(); use_it != user_database.end(); ++use_it) {
        use_it->second->dump(ofile);
    }
    ofile << "</users>\n";
}

/**
 * Allow user to add a product from the previously generated "hits" list into their cart.
 */

void MyDataStore::add_to_cart(std::vector<Product*> hits, std::string username, int index) {
    // Firstly we check if the given username matches an user in our user_database
    // If not, we have to return the error code: Invalid request
    if (user_database.find(username) != user_database.end()) {
        // Successfully found user, now check if the index is valid
        if (index > (int)hits.size()) {
            // This index is invalid,
            std::cout << "Invalid request" << std::endl;
            return;
        }
        // Index is valid, See if this user has cart
        if (cart_database.find(username) != cart_database.end()) {
            // This user has an established cart, now add the said item into card
            cart_database.find(username)->second.push_back(hits[index - 1]);
        } else {
            // This user doesn't have a cart yet, need to make one now
            std::deque<Product*> new_cart;
            new_cart.push_back(hits[index - 1]);
            cart_database[username] = new_cart;
        }
    } else {
        // Found no matching username
        std::cout << "Invalid request" << std::endl;
        return;
    }
}

/**
 * Allow user to see the items in their cart.
 */

void MyDataStore::view_cart(std::string username) {
    // check if this username exists in our cart_database, if they are in the cart,
    // they're in user_database

    if (cart_database.find(username) != cart_database.end()) {
        // This user exist in our database
        std::deque<Product*> user_cart = cart_database.find(username)->second;
        int item_no = 1;
        for (std::deque<Product*>::iterator it = user_cart.begin(); it != user_cart.end(); ++it) {
            std::cout << "Item " << item_no << std::endl;
            std::cout << (*it)->displayString() << std::endl;
            std::cout << std::endl;
            item_no++;
        }
        return;
    } else {
        // This username doesn't exist in our database, invalid username
        std::cout << "Invalid username" << std::endl;
        return;
    }
}

/**
 * Allow user to purchase the items in their cart.
 */

void MyDataStore::buy_cart(std::string username) {
    if (cart_database.find(username) != cart_database.end()) {
        // This user exist in our database
        std::deque<Product*>::iterator it = cart_database.find(username)->second.begin();
        while (it
               != cart_database.find(username)
                          ->second.end()) {  // So long as we haven't reach the end, gonna keep loopin'
            User* our_customer = user_database.find(username)->second;
            if (((*it)->getQty() > 0) && (our_customer->getBalance() >= (*it)->getPrice())) {
                // we have enough stock AND customer has enough buck!
                our_customer->deductAmount((*it)->getPrice());     // get customer's money
                (*it)->subtractQty(1);                             // give customer our product
                ++it;                                              // increment the iterator
                cart_database.find(username)->second.pop_front();  // we can now pop this item in the cart
            } else {
                ++it;  // ignore this item
            }
        }
        return;
    } else {
        // This username doesn't exist in our database, invalid username
        std::cout << "Invalid username" << std::endl;
        return;
    }
}

/***
 *Data members in this class:
 *
 *std::map<std::string, std::set<Product*>> product_database; // <keyword, Product* that contain keyword>
 *
 *std::set<Product*> all_products; // contains all the products available in product_database
 *
 *std::set<std::string> all_keywords; // contains all the keywords available in product_database
 *
 *std::map<std::string, User*> user_database; // <username, User*>
 *
 *std::map<std::string, std::deque<Product*>> cart_database; // <username. Product* that were added>
 *
 *
 */
