//
//  regrade_test.cpp
//
//
//  Created by Simon To on 4/3/21.
//

#include "ulliststr.h"  //
#include <cstddef>
#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {
    ULListStr list;

    for (int count = 0; count < 4; ++count) {
        list.push_back("test");

        cout << list.get(0) << endl;

        list.pop_back();

        cout << list.size() << endl;   // 0
        cout << list.empty() << endl;  // true
    }
}
