//
//  Hashtable.cpp
//  Hashtable
//
//  Created by Simon To on 26/4/21.
//

#include "Hashtable.h"



Hashtable::Hashtable(bool debug, unsigned int probing) {

    this->debug_mode = debug;
    this->probing_mode = probing;
    this->table = new std::pair<std::string, int>* [11] { nullptr };  // Set all elements to null first
    this->current_size = 0;
    this->table_size = 11;
    this->size_tracker = 0;

    if (this->debug_mode == true) {  // Debug mode is on
        this->r[0] = 983132572;
        this->r[1] = 62337998;
        this->r[2] = 552714139;
        this->r[3] = 984953261;
        this->r[4] = 261934300;
    } else {  // Debug mode is off
        this->five_random(this->table_size);
    }
}

Hashtable::~Hashtable() {
    for (int i = 0; i < this->table_size; i++) {
        if (this->table[i] != nullptr) {  // If this item is filled
            delete this->table[i];        // Delete this item
        }
    }

    delete[] this->table;  // Lastly, delete the entire table
}

// Call the following function in: Constructor, resize() when the debug mode is off
void Hashtable::five_random(int m) {  // generate 5 new r values that are random numbers between 0 and m-1 (inclusive)
    for (int i = 0; i < 5; i++) {
        this->r[i] = (rand() % (this->table_size));
    }
}

void Hashtable::w_calculator(std::string k, int (&w)[5]) const {

    int none_zero_w = ceil(((double)k.size()) / (double)6);  // How many indices of w are we filling?
    int max_index = ((int)k.size()) - 1;                     // The maximum index for string k

    for (int i = 4; i >= (5 - none_zero_w); i--) {

        int counter = 0;
        if (i == (5 - none_zero_w)) {
            for (int j = (max_index - ((4 - i) * 6)); j >= 0; j--) {
                w[i] += (k[j] - 'a') * pow(26, counter);
                counter += 1;
            }
        } else {
            for (int j = (max_index - ((4 - i) * 6)); j >= (max_index - ((4 - i) * 6)) - 5; j--) {
                w[i] += (k[j] - 'a') * pow(26, counter);
                counter += 1;
            }
        }
    }
}

int Hashtable::hash(std::string k) const {
    int w[5];
    for (int j = 0; j < 5; j++) {
        w[j] = 0;
    }

    this->w_calculator(k, w);

    long long sum = 0;
    for (int i = 0; i < 5; i++) {
        sum += ((long long)(this->r[i]) * (long long)w[i]);
    }

    int result = sum % (this->table_size);

    return result;
}

int Hashtable::hash2(std::string k) const {
    int w[5];
    for (int j = 0; j < 5; j++) {
        w[j] = 0;
    }

    this->w_calculator(k, w);

    int sum_w = 0;

    for (int i = 0; i < 5; i++) {
        sum_w += w[i];
    }

    // h(w) = p - ((w1+w2+w3+w4+w5) % p)
    int result = (this->available_p[this->size_tracker]) - (sum_w % (this->available_p[this->size_tracker]));

    return result;
}

std::pair<std::string, int>* Hashtable::find(std::string k) {  // Helper function used in count() and add()
    int target_loc;
    if (this->probing_mode == 0) {                              // Linear-probing
        target_loc = this->hash(k);                             // Get the default location of key
        if ((this->table[target_loc]) != nullptr) {             // If the target location is a valid pair
            if ((this->table[target_loc])->first == k) {        // Target is at the default location
                return (this->table[target_loc]);               // return the pointer of target
            } else {                                            // Target is not at the default location, start probing
                std::pair<std::string, int>* result = nullptr;  // return statement if the target is not found
                int step = 1;                                   // Go to the next possible location
                int actual_loc = (target_loc + step) % (this->table_size);
                while (this->table[actual_loc] != nullptr) {      // As long as we haven't hit a blank space
                    if ((this->table[actual_loc])->first != k) {  // Target is not at this location
                        if (step < this->table_size) {
                            step += 1;  // Move to the next location in the next iteration
                            actual_loc = (target_loc + step) % (this->table_size);
                        }
                    } else {                                 // Target is found at this location
                        result = (this->table[actual_loc]);  // Record the result
                        break;                               // No need for any more iterations
                    }
                }
                return result;  // return the pointer of target
            }
        } else {             // The target location is not valid
            return nullptr;  // Target is NOT in table
        }
    } else if (this->probing_mode == 1) {                 // Quadratic-probing
        target_loc = this->hash(k);                       // Get the default location of key
        if ((this->table[target_loc]) != nullptr) {       // If the target location is a valid pair
            if ((this->table[target_loc])->first == k) {  // Target is at the default location
                return (this->table[target_loc]);         // return the pointer of target
            } else {                                      // Target is not at the default location, start probing
                // In this case, target_loc should always remain at default location
                std::pair<std::string, int>* result = nullptr;  // return statement if the target is not found
                int sqrt_step = 1;                              // Square-rooted step size
                int actual_loc = (target_loc + (int)pow(sqrt_step, 2)) % (this->table_size);
                while (this->table[actual_loc] != nullptr) {      //
                    if ((this->table[actual_loc])->first != k) {  // Target is not at this location
                        if (sqrt_step < this->table_size) {
                            sqrt_step += 1;  // Move to the next location in the next iteration
                            actual_loc = (target_loc + (int)pow(sqrt_step, 2)) % (this->table_size);
                        }
                    } else {                                 // Target is found at this location
                        result = (this->table[actual_loc]);  // Record the result
                        break;                               // No need for any more iterations
                    }
                }
                return result;  // return the pointer of target
            }
        } else {             // The target location is not valid
            return nullptr;  // Target is NOT in table
        }

    } else {                                                    // Double-hashing
        target_loc = this->hash(k);                             // Get the default location of key
        if ((this->table[target_loc]) != nullptr) {             // If the target location is a valid pair
            if ((this->table[target_loc])->first == k) {        // Target is at the default location
                return (this->table[target_loc]);               // return the pointer of target
            } else {                                            // Target is not at the default location, start probing
                int step_size = this->hash2(k);                 // Find the step size for probing.
                int step_num = 1;                               // Start with one step
                std::pair<std::string, int>* result = nullptr;  // return statement if the target is not found
                int actual_loc = (target_loc + (step_size * step_num)) % (this->table_size);
                while (this->table[actual_loc] != nullptr) {
                    if ((this->table[actual_loc])->first != k) {  // Target is not at this location
                        if (step_num < this->table_size) {
                            step_num += 1;  // Move to the next location in the next iteration
                            actual_loc = (target_loc + (step_size * step_num)) % (this->table_size);
                        }
                    } else {                                 // Target is found at this location
                        result = (this->table[actual_loc]);  // Record the result
                        break;                               // No need for any more iterations
                    }
                }
                return result;  // return the pointer of target
            }
        } else {             // The target location is not valid
            return nullptr;  // Target is NOT in table
        }
    }
}

int Hashtable::next_empty(std::string k, std::pair<std::string, int>** target_table) {
    int target_loc;
    if (this->probing_mode == 0) {                    // Linear-probing
        target_loc = this->hash(k);                   // Get the default location
        if ((target_table[target_loc]) == nullptr) {  // Target is empty
            return target_loc;                        // Return the index of interest
        } else {                                      // Target is not empty at the default location, start probing
            int result = target_loc;                  // Begin from the default index
            int step = 1;                             // Go to the next possible location
            int actual_loc = (target_loc + step) % (this->table_size);
            while (target_table[actual_loc] != nullptr) {  // As long as we haven't hit a blank space
                if (step < this->table_size) {
                    step += 1;  // Move to the next location in the next iteration
                    actual_loc = (target_loc + step) % (this->table_size);
                }
            }
            result = actual_loc;  // Update result with the desired index
            return result;        // Return the index of interest
        }
    } else if (this->probing_mode == 1) {             // Quadratic-probing
        target_loc = this->hash(k);                   // Get the default location of key
        if ((target_table[target_loc]) == nullptr) {  // Target is empty
            return target_loc;                        // Return the index of interest
        } else {                                      // Target is not at the default location, start probing
            // In this case, target_loc should always remain at default location
            int result = target_loc;  // Begin from the default index
            int sqrt_step = 1;        // Square-rooted step size
            int actual_loc = (target_loc + (int)pow(sqrt_step, 2)) % (this->table_size);
            while (target_table[actual_loc] != nullptr) {
                if (sqrt_step < this->table_size) {
                    sqrt_step += 1;  // Move to the next location in the next iteration
                    actual_loc = (target_loc + (int)pow(sqrt_step, 2)) % (this->table_size);
                }
            }
            result = actual_loc;  // Update result with the desired index
            return result;        // return the pointer of target
        }
    } else {                                          // Double-hashing
        target_loc = this->hash(k);                   // Get the default location of key
        if ((target_table[target_loc]) == nullptr) {  // Target is empty
            return target_loc;                        // Return the index of interest
        } else {                                      // Target is not at the default location, start probing
            int result = target_loc;                  // Begin from the default index
            int step_size = this->hash2(k);           // Find the step size for probing.
            int step_num = 1;                         // Start with one step
            int actual_loc = (target_loc + (step_size * step_num)) % (this->table_size);
            while (target_table[actual_loc] != nullptr) {
                if (step_num < (this->table_size)) {
                    step_num += 1;  // Move to the next location in the next iteration
                    actual_loc = (target_loc + (step_size * step_num)) % (this->table_size);
                }
            }
            result = actual_loc;  // Update result with the desired index
            return result;        // return the pointer of target
        }
    }
}

int Hashtable::count(std::string k) {  // Return the value associate with key (0 if k is not in the Hashtable)
    std::pair<std::string, int>* target_pair = this->find(k);  // Find the pointer to our target pair
    if (target_pair != nullptr) {
        int result = target_pair->second;  // Find the value in that pair
        return result;                     // Done!
    } else {
        return 0;  // Not found
    }
}

void Hashtable::resize() {
    // 1. Change the table size to the immediate higher value
    this->size_tracker += 1;                                 // Increment the position of the index of size array
    int old_size = this->table_size;                         // Reserve the old table size for later use
    this->table_size = available_sizes[this->size_tracker];  // Increment table size to the next value

    // 2. Generate new r1 r2 r3 r4 r5 if the debuf_mode is false
    // Beginning of reassigning r values
    if (this->debug_mode == false) {          // Debug mode is off
        this->five_random(this->table_size);  // Re-generate the 5 r values
    }
    // Ending of reassigning r values

    // 3. Relocate ALL of the members in the table (NOT DONE YET!!)

    // We begin by creating a new table
    std::pair<std::string, int>** new_table
            = new std::pair<std::string, int>* [this->table_size] { nullptr };  // Set all to null pointer first

    for (int i = 0; i < old_size; i++) {                         // Transferring ALL of the items in hashtable
        if (this->table[i] != nullptr) {                         // This element contains a pair
            std::string keyword = (this->table[i])->first;       // Fetch the keyword
            int new_loc = this->next_empty(keyword, new_table);  // Find an ideal place to put this pair
            new_table[new_loc] = this->table[i];                 // Enter this new element into new table
        }
    }

    // We tie up the lose ends by deleting the old table
    std::pair<std::string, int>** to_delete = this->table;
    delete[] to_delete;

    // We finish off by assign the new table to be out hashtable
    this->table = new_table;
}

void Hashtable::add(std::string k) {
    double load_factor = (double)(this->current_size) / (double)(this->table_size);
    if (load_factor >= 0.5) {  // Need to resize before adding
        this->resize();
    }

    // Add the new string
    std::pair<std::string, int>* prob_result = this->find(k);

    // If this string already exists
    if (prob_result != nullptr) {
        prob_result->second += 1;
    } else {  // If this string doesn't yet exists
        std::pair<std::string, int>* new_pair = new std::pair<std::string, int>(k, 1);  // Instantiate new pair
        int target_loc = this->next_empty(k, this->table);  // Find where to put that new pair
        this->table[target_loc] = new_pair;
        this->current_size += 1;
    }
}

void Hashtable::reportAll(std::ostream& os) const {
    for (int i = 0; i < this->table_size; i++) {
        if (this->table[i] != nullptr) {  // If this is a valid pair
            // on each line, output the key, followed by a space, followed by the value, and then a newline.
            os << (this->table[i])->first << " " << (this->table[i])->second << std::endl;
        }
    }
}

/*


 11,
 23,
 47,
 97,
 197,
 397,
 797,
 1597,
 3203,
 6421,
 12853,
 25717,
 51437,
 102877,
 205759,
 411527,
 823117,
 1646237,
 3292489,
 6584983,
 13169977,
 26339969,
 52679969,
 105359969,
 210719881,
 421439783,
 842879579,
 1685759167

 */

/*
ULListStr::ULListStr() {
    head_ = NULL;
    tail_ = NULL;
    size_ = 0;
}

ULListStr::~ULListStr() { clear(); }

bool ULListStr::empty() const { return size_ == 0; }
*/
